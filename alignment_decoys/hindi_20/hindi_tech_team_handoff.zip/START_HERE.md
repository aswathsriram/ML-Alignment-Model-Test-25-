# Hindi alignment test — tech-team handoff

Upload this ZIP to Google Drive, or extract it and upload this folder. The transcript data is unchanged from the validated Hindi package in GitHub; this handoff separates the files by use.

## Main updated transcript file

**01_UPDATED_TRANSCRIPTS/alignment_prefill_hi_IN.json**

This is the combined updated transcript file for all **20 Hindi clips**, in the same prefill structure as the Spanish deliverable: `fileMetadata` and `items[]`. Each item has `id`, `name`, `locale`, `transcript`, and `source.words[]`. Word timings are numeric seconds in `start` and `end`. Use `id` to match grading records and `name` to match your existing audio files. Audio is not included in this handoff.

Use this file for the full test of **405 weighted error checks**. It contains the preserved existing errors plus 104 additions. Do not use the original JSON or the gold/reference data as the trainee prefill. Do not re-run forced alignment before the test: that would overwrite the planted timing errors. Missing timing chips can leave words in `transcript` without a corresponding entry in `source.words`; do not regenerate the transcript solely from the words array. Some supplied overlap errors remain intentionally present.

## Answer keys — admin / grading only

Keep **02_ADMIN_ONLY/** restricted to the tech/admin team. Do not share it with annotators taking the test. JSON, CSV and Excel answer keys describe original and modified words, timing shifts, bands, weights, and whether an error was preserved or newly added.

Full-corpus points: boundaries 50; missing chips 10; extra chips 10; wrong words 10; segmentation 10; guideline errors 10. Within each group A1:A2:A3 has a 3:2:1 factor. Aggregate score is 100 × caught weights / attempted weights. The answer-key JSON has the exact per-error weights.

The supplied Hindi-specific scorer handles the existing extra words over speech, which the earlier Spanish silence-only detector does not cover. Candidate submissions are a JSON list of `{file_id, segments}`, each segment using `transcription`, `startTime`, `endTime` with HH:MM:SS.mmm timestamps. Run from this handoff folder:

```
python3 02_ADMIN_ONLY/alignment.py 02_ADMIN_ONLY/answer_key.json submissions.json > scores.json
```

Python standard library only. Additional unlisted submission mistakes need separate quality review.

## Alternative supported-template test

**03_SUPPORTED_TEMPLATE_ALTERNATIVE/** is an optional, different test: 20 active records and **98 supported injections**, using `align-decoy-kit/v1`. Use its `decoy_corpus.json` together with its own `alignment_prefill_hi_IN_supported.json`. This subset omits unsupported small shifts and text changes, so do not pair it with the full 405-event test or full answer key. If importing as an audio kit, supply the matching audio first.

## Validation and limits

All 405 unchanged-test, reference-answer, and reference-with-±20 ms-jitter grading controls passed. Twenty partial-correction controls also passed. No gold data was changed. No new overlap or invalid spans were introduced; the original test's overlap errors were preserved.

No audio was supplied. Acoustic correctness of gold, actual silence, and platform import have not been independently verified. See the validation report and summary for details.
