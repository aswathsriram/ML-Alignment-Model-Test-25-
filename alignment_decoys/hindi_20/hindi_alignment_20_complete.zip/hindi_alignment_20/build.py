"""Audit and extend existing Hindi alignment tests without overwriting existing errors."""
import collections
import copy
import csv
import hashlib
import json
import pathlib
import random
import re
import shutil
import zipfile

from alignment import align,band,compare,milliseconds,norm,public,segments,severity,stamp,words

ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path('/workspace/attachments/0e1ae005-92ca-4584-8a78-7cdb0fee2a7f/hi_alignment_test_20 (2).json')
TEMPLATE=ROOT/'uploaded_template.json' if (ROOT/'uploaded_template.json').exists() else pathlib.Path('/workspace/attachments/be9a4a70-aba2-4d37-b13a-9f591d303911/decoy_corpus.template (1).json')
NUMBERS=dict(zip('शून्य एक दो तीन चार पांच पाँच छह छः सात आठ नौ दस ग्यारह बारह तेरह चौदह पंद्रह पन्द्रह सोलह सत्रह अठारह उन्नीस बीस इक्कीस तीस चालीस पचास साठ सत्तर अस्सी नब्बे सौ'.split(),
                ['0','1','2','3','4','5','5','6','6','7','8','9','10','11','12','13','14','15','15','16','17','18','19','20','21','30','40','50','60','70','80','90','100']))
SHARES={'BOUNDARY':50,'MISSING':10,'HALLUCINATED':10,'WRONG-WORD':10,'SEGMENTATION':10,'GUIDELINE':10}


def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def save(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')


def group(f):
    if f.startswith('BND-'):return 'BOUNDARY'
    if f.startswith('SEG-'):return 'SEGMENTATION'
    if f.startswith('G-'):return 'GUIDELINE'
    return {'WD':'MISSING','WH':'HALLUCINATED','WS':'WRONG-WORD'}[f]


def event_identity(e,gold,test):
    # Test indices move when unrelated chips are inserted/removed; interval/text evidence is stable.
    payload={k:v for k,v in e.items() if k not in ['test_indices','gold_indices']}
    return canonical({'event':payload,'gold_indices':e['gold_indices'],'test_segments':public([test[i] for i in e['test_indices']])})


def gap_compatible(event,gold,test):
    if event['rule']!='extra':return False
    k=event['inserted_before_index'];w=test[event['test_indices'][0]]
    return 1<=k<len(gold) and gold[k-1]['e']<w['s']<w['e']<gold[k]['s']


def plan(record):
    G,T=words(record['gold']['segments']),words(record['test']['segments'])
    existing,diagnostics,path=compare(G,T)
    mapping={st['gold_indices'][0]:st['test_indices'][0] for st in path if st['kind']=='match'}
    clean={k:j for k,j in mapping.items() if G[k]==T[j] and any(c.isalnum() for c in G[k]['word']) and not G[k]['word'].startswith(('[','<'))}
    dirty=set(range(len(G)))-set(clean)
    added=[];used=set();rng=random.Random('hindi-20261105:'+record['file_id'])
    needed=[]
    for size in ['minor','major','critical']:
        if not any(e['rule']=='boundary' and e['severity']==size for e in existing):needed.append(size)
    families={e['family'] for e in existing}
    for family in ['WD','SEG-MERGE','WS','G-NUM','G-CASE','G-PUNCT','SEG-LETTERS']:
        if family not in families:needed.append(family)
    if not any(gap_compatible(e,G,T) for e in existing):needed.append('WH-gap')
    unavailable=[]
    for need in needed:
        choices=[]
        for k,j in clean.items():
            w=T[j]
            if need in {'minor','major','critical'}:
                magnitudes={'minor':[40,50,60,70,80],'major':[150,180,200,250,300],'critical':[320,350,400,450,500,600]}[need]
                previous=T[j-1]['e'] if j else 0
                following=T[j+1]['s'] if j+1<len(T) else round(record['duration_seconds']*1000)
                for edge in ['s','e']:
                    for d in magnitudes:
                        for sign in [-1,1]:
                            a,b=w['s'],w['e']
                            if edge=='s':a+=sign*d
                            else:b+=sign*d
                            if a>=max(0,previous) and b<=following and b-a>=40:
                                choices.append({'need':need,'action':'boundary','gold_indices':[k],'test_indices':[j],
                                                'new_s':a,'new_e':b,'edge':edge,'shift_ms':sign*d})
            elif need=='WD':choices.append({'need':need,'action':'delete','gold_indices':[k],'test_indices':[j]})
            elif need=='WS':choices.append({'need':need,'action':'text','gold_indices':[k],'test_indices':[j],'replacement':'कल' if w['word']!='कल' else 'आज'})
            elif need=='G-NUM' and w['word'] in NUMBERS:
                choices.append({'need':need,'action':'text','gold_indices':[k],'test_indices':[j],'replacement':NUMBERS[w['word']]})
            elif need=='G-CASE' and re.fullmatch('[a-z][a-z-]*',w['word']):
                choices.append({'need':need,'action':'text','gold_indices':[k],'test_indices':[j],'replacement':w['word'].capitalize()})
            elif need=='G-PUNCT' and w['word'][-1:].isalnum():
                choices.append({'need':need,'action':'text','gold_indices':[k],'test_indices':[j],'replacement':w['word']+'।'})
            elif need=='SEG-MERGE' and clean.get(k+1)==j+1 and T[j]['e']<=T[j+1]['s']:
                choices.append({'need':need,'action':'merge','gold_indices':[k,k+1],'test_indices':[j,j+1]})
            elif need=='SEG-LETTERS' and re.fullmatch('[a-z]\\.',w['word']):
                stop=k+1
                while stop in clean and clean[stop]==j+stop-k and re.fullmatch('[a-z]\\.',G[stop]['word']):stop+=1
                if stop-k>=2:choices.append({'need':need,'action':'letters','gold_indices':list(range(k,stop)),
                                             'test_indices':list(range(j,j+stop-k))})
            elif need=='WH-gap' and k>0 and clean.get(k-1)==j-1:
                lo,hi=T[j-1]['e'],w['s']
                if hi-lo>=200:
                    middle=(lo+hi)//2;half=min(120,(hi-lo-80)//2)
                    choices.append({'need':need,'action':'insert','gold_indices':[k-1,k],'test_indices':[j-1,j],
                                    'before_gold':k,'before_test':j,'word':'अचानक','new_s':middle-half,'new_e':middle+half})
        rng.shuffle(choices)
        picked=None
        for spacing in [3,2,1]:
            safe=[c for c in choices if all(abs(a-b)>=spacing for a in c['gold_indices'] for b in used)]
            if safe:
                # Prefer changes away from preexisting errors, reducing interactions with old test edits.
                safe.sort(key=lambda c:min((abs(a-b) for a in c['gold_indices'] for b in dirty),default=100),reverse=True)
                picked=safe[0];break
        if picked:
            used.update(picked['gold_indices']);added.append(picked)
        else:unavailable.append({'family_or_severity':need,'reason':'No safe untouched source slot available for this type; Hindi-specific applicability and previous errors preserved.'})
    return added,existing,diagnostics,path,unavailable


def apply(T,operations,keep_deleted_in_transcript=False):
    by={};extra={}
    for op in operations:
        if op['action']=='insert':extra[op['before_test']]=op
        else:by[op['test_indices'][0]]=op
    result=[];j=0
    while j<len(T):
        if j in extra:
            c=extra[j];result.append({'word':c['word'],'s':c['new_s'],'e':c['new_e']})
        w=copy.deepcopy(T[j]);op=by.get(j)
        if op:
            if op['action']=='delete':
                if keep_deleted_in_transcript:result.append(w)
                j+=1;continue
            if op['action']=='boundary':w.update(s=op['new_s'],e=op['new_e'])
            elif op['action']=='text':w['word']=op['replacement']
            elif op['action'] in {'merge','letters'}:
                pieces=[T[x] for x in op['test_indices']]
                text=' '.join(w['word'] for w in pieces) if op['action']=='merge' else ''.join(w['word'].rstrip('.') for w in pieces)
                w={'word':text,'s':pieces[0]['s'],'e':pieces[-1]['e']}
                j=max(op['test_indices'])+1;result.append(w);continue
        result.append(w);j+=1
    return result


def audit_original(record,path):
    G,T=words(record['gold']['segments']),words(record['test']['segments'])
    mapping={s['gold_indices'][0]:s['test_indices'][0] for s in path if s['kind']=='match'}
    extras=[s['test_indices'][0] for s in path if s['kind']=='insert']
    missing={s['gold_indices'][0] for s in path if s['kind']=='delete'}
    audits=[]
    for ix,e in enumerate(record['answer_key']):
        k=e['gold_index'];result={'original_entry_index':ix,'original_entry':copy.deepcopy(e),'status':'VERIFIED'}
        if e['error_class']=='alignment':
            if k not in mapping:result.update(status='NOT_LOCATED',reason='Original gold index has no directly matched test chip.')
            else:
                g,t=G[k],T[mapping[k]];ds=t['s']-g['s'];de=t['e']-g['e'];d=max(abs(ds),abs(de))
                result.update(start_shift_ms=ds,end_shift_ms=de,measured_max_delta_ms=d,
                              measured_severity=severity(d),above_30ms_scoring_tolerance=d>30)
                actual=[stamp(t['s']),stamp(t['e'])];reference=[stamp(g['s']),stamp(g['e'])]
                if actual!=e.get('test_value') or reference!=e.get('gold_value') or d!=e.get('max_delta_ms'):
                    result.update(status='METADATA_MISMATCH',reason='Listed timing/value/delta differs from the supplied gold/test arrays; arrays are authoritative.')
        elif e['error_type']=='word_deletion':
            if k not in missing:result.update(status='NOT_LOCATED',reason='Listed deletion was not found by token/time alignment.')
        elif e['error_type']=='word_hallucination':
            found=[j for j in extras if norm(T[j]['word'])==norm(e.get('test_value',''))]
            if not found:result.update(status='NOT_LOCATED',reason='Listed extra word was not found as an unmatched test chip.')
            else:result['candidate_test_indices']=found
        elif k not in mapping or T[mapping[k]]['word']!=e.get('test_value') or G[k]['word']!=e.get('gold_value'):
            result.update(status='METADATA_MISMATCH',reason='Listed word value differs from the aligned gold/test arrays.')
        audits.append(result)
    return audits


def kit_and_prefill(key):
    G=words(key['gold_source_segments']);eligible=[]
    for e in key['injections']:
        family=e['family'];gs=e['gold_indices'];ts=e['test_segments'];meta={}
        if e['rule']=='boundary' and abs(e['shift_ms'])>=150:
            k=gs[0];g=G[k];target=copy.deepcopy(g)
            edge='s' if e['edge']=='start' else 'e';target[edge]+=e['shift_ms']
            before=G[k-1]['e'] if k else 0;after=G[k+1]['s'] if k+1<len(G) else round(key['duration_seconds']*1000)
            if target['s']<before or target['e']>after or target['e']-target['s']<30:continue
            meta={'plain_offset':k,'word':g['word'],'edge':e['edge'],'shift_ms':e['shift_ms'],'severity':e['severity'],
                  'decoy':{'start':target['s']/1000,'end':target['e']/1000}}
        elif family=='WD':meta={'plain_offset':gs[0],'word':G[gs[0]]['word']}
        elif family=='WH':
            k=e['inserted_before_index'];w=ts[0]
            if not 1<=k<len(G) or not G[k-1]['e']/1000<w['start']<w['end']<G[k]['s']/1000:continue
            meta={'inserted_before_index':k,'word':w['word'],'decoy':{'start':w['start'],'end':w['end']},'audio_silence_verified':False}
        elif family=='SEG-MERGE':meta={'plain_offset':gs[0]}
        else:continue
        affected=set(gs) if family!='WH' else {meta['inserted_before_index']-1,meta['inserted_before_index']}
        eligible.append((e,meta,affected))
    occupied=set();selected=[]
    for f in ['WD','SEG-MERGE','WH','BND-MAJOR']:
        candidates=[x for x in eligible if x[0]['family']==f and not x[2].intersection(occupied)]
        candidates.sort(key=lambda x:(x[0]['band']=='A1',abs(x[0].get('shift_ms',0))),reverse=True)
        if candidates:
            e,m,used=candidates[0];selected.append((e,m));occupied.update(used)
    for e,m,used in sorted(eligible,key=lambda x:abs(x[0].get('shift_ms',0)),reverse=True):
        if len(selected)>=6:break
        if not used.intersection(occupied):selected.append((e,m));occupied.update(used)
    injections=[{'injection_id':e['injection_id'],'family':e['family'],'band':e['band'],'weight':e['weight'],'meta':m} for e,m in selected]
    if injections and not any(x['band']=='A1' for x in injections):
        injections[0]['band']='A1';injections[0]['meta']['note']='Highest-priority supported error for this clip; raw severity is recorded separately.'
    kit={'decoy_id':key['decoy_id'],'locale':'hi_IN','file_name':key['file_name'],'duration_seconds':key['duration_seconds'],
         'status':'ACTIVE' if injections else 'INACTIVE','gold_whole_audio_tag':'none','gold_segments':key['gold_segments'],'injections':injections}
    # Build the supported subset from gold, rather than leaking incompatible old text/overlap errors into it.
    replacement={};deleted=set();merges={};extra={}
    for x in injections:
        m=x['meta'];f=x['family']
        if f=='WD':deleted.add(m['plain_offset'])
        elif f=='BND-MAJOR':
            w=copy.deepcopy(G[m['plain_offset']]);w['s' if m['edge']=='start' else 'e']=round(m['decoy'][m['edge']]*1000);replacement[m['plain_offset']]=w
        elif f=='SEG-MERGE':merges[m['plain_offset']]=True
        else:extra[m['inserted_before_index']]={'word':m['word'],'s':round(m['decoy']['start']*1000),'e':round(m['decoy']['end']*1000)}
    result=[];k=0
    while k<len(G):
        if k in extra:result.append(extra[k])
        if k in merges:
            result.append({'word':G[k]['word']+' '+G[k+1]['word'],'s':G[k]['s'],'e':G[k+1]['e']});k+=2;continue
        if k not in deleted:result.append(replacement.get(k,G[k]))
        k+=1
    prefill={'id':key['file_id'],'name':key['file_name'],'locale':'hi_IN','transcript':key['gold_text'],
             'source':{'duration_seconds':key['duration_seconds'],'words':public(result)}}
    return kit,prefill


def build(source,out):
    original=json.loads(source.read_text());assert len(original)==20 and len({r['file_id'] for r in original})==20
    out.mkdir(parents=True,exist_ok=True);enriched=copy.deepcopy(original);keys=[];audit_rows=[];changes=[];coverage=[]
    for r,updated in zip(original,enriched):
        operations,old_events,diagnostics,path,unavailable=plan(r)
        G,T=words(r['gold']['segments']),words(r['test']['segments'])
        revised=apply(T,operations)
        updated['test']['segments']=segments(revised)
        if operations:updated['test']['full_transcript']=' '.join(w['word'] for w in apply(T,operations,keep_deleted_in_transcript=True))
        final_events,final_diag,final_path=compare(G,revised)
        old_signatures={event_identity(e,G,T) for e in old_events}
        final_signatures={event_identity(e,G,revised) for e in final_events}
        assert old_signatures.issubset(final_signatures),r['file_id']
        decoy_id='HI-EXISTING-'+r['file_id']+'-'+sha(canonical(public(G)))[:8]
        injections=[]
        for i,e in enumerate(final_events,1):
            e=copy.deepcopy(e);origin='preserved_input' if event_identity(e,G,revised) in old_signatures else 'newly_planted'
            e.update(injection_id=f'{decoy_id}-{i:03d}',band=band(e),weight=0,origin=origin,
                     gold_segments=public([G[k] for k in e['gold_indices']]),test_segments=public([revised[j] for j in e['test_indices']]))
            e['score_group']=group(e['family']);injections.append(e)
        audit=audit_original(r,path)
        audit_rows.append({'file_id':r['file_id'],'original_reported_errors':r['n_errors_seeded'],'original_entries':audit,
                           'actual_scorable_events':len(old_events),'small_boundary_differences_not_scored':diagnostics,
                           'note':'A listed error may contain two edge changes; unlisted donor-edge changes are also measured. Counts are not one-to-one.'})
        key={'decoy_id':decoy_id,'file_id':r['file_id'],'file_name':r['audio_id'],'locale':'hi_IN','duration_seconds':r['duration_seconds'],
             'gold_text':r['gold']['full_transcript'],'decoy_text':updated['test']['full_transcript'],
             'gold_segments':public(G),'decoy_segments':public(revised),'gold_source_segments':copy.deepcopy(r['gold']['segments']),
             'test_source_segments':copy.deepcopy(updated['test']['segments']),'injections':injections,
             'existing_listed_error_count':len(r['answer_key']),'existing_scorable_event_count':len(old_events),
             'newly_planted_event_count':sum(e['origin']=='newly_planted' for e in injections),
             'small_boundary_differences_not_scored':final_diag,'gold_is_supplied_reference_not_audio_verified':True}
        keys.append(key)
        updated['source_reported_counts']={k:r[k] for k in ['n_errors_seeded','errors_transcription','errors_alignment','errors_from_real_ai','errors_invisible_to_a_human']}
        updated['original_answer_key']=copy.deepcopy(r['answer_key'])
        updated['answer_key']=copy.deepcopy(injections)
        updated['n_errors_seeded']=len(injections)
        updated['errors_alignment']=sum(e['rule'] in {'boundary','missing','extra','merge'} for e in injections)
        updated['errors_transcription']=len(injections)-updated['errors_alignment']
        updated['provenance_note']='errors_from_real_ai and errors_invisible_to_a_human retain the original source claims unchanged, also copied in source_reported_counts. These are not updated or independently verified for newly added changes; audio is unavailable.'
        changes.append({'file_id':r['file_id'],'file_name':r['audio_id'],'operations_added':operations,'unavailable_types':unavailable})
        coverage.append({'file_id':r['file_id'],'existing_families':sorted({e['family'] for e in old_events}),
                         'final_families':sorted({e['family'] for e in injections}),'added_families_or_severities':[op['need'] for op in operations],
                         'unavailable_types':unavailable})
    # Reference default: boundaries 50%, each other alignment/transcription group 10%.
    factors={'A1':3,'A2':2,'A3':1};den=collections.Counter()
    for r in keys:
        for e in r['injections']:den[e['score_group']]+=factors[e['band']]
    for r,u in zip(keys,enriched):
        for e in r['injections']:
            e['weight']=round(SHARES[e['score_group']]*factors[e['band']]/den[e['score_group']],8)
            e['fingerprint']=sha(canonical(e))[:16]
        u['answer_key']=copy.deepcopy(r['injections'])
    kits=[];supported=[]
    for key in keys:
        kit,prefill=kit_and_prefill(key);kits.append(kit);supported.append(prefill)
    kit_factors=collections.Counter()
    for k in kits:
        for e in k['injections']:kit_factors[e['family']]+=factors[e['band']]
    for k in kits:
        for e in k['injections']:
            points=50 if e['family']=='BND-MAJOR' else 50/3
            e['weight']=round(points*factors[e['band']]/kit_factors[e['family']],8)
    save(out/'hi_alignment_test_20_enriched.json',enriched)
    save(out/'answer_key.json',keys);save(out/'existing_error_audit.json',audit_rows)
    save(out/'changes_added.json',changes);save(out/'coverage_by_file.json',coverage)
    save(out/'decoy_corpus.json',{'format':'align-decoy-kit/v1','instructions':json.loads(TEMPLATE.read_text())['instructions'],'decoys':kits})
    save(out/'alignment_prefill_hi_IN_supported.json',{'fileMetadata':{'locale':'hi_IN','workitemsCount':20},'items':supported})
    full_prefill={'fileMetadata':{'locale':'hi_IN','workitemsCount':20},'items':[
        {'id':k['file_id'],'name':k['file_name'],'locale':'hi_IN','transcript':k['decoy_text'],'source':{'duration_seconds':k['duration_seconds'],'words':k['decoy_segments']}} for k in keys]}
    save(out/'alignment_prefill_hi_IN.json',full_prefill)
    for r in full_prefill['items']:save(out/'modified_transcripts'/(r['id']+'.json'),r)
    summary={'source_records':20,'source_listed_errors':sum(len(r['answer_key']) for r in original),
             'existing_scorable_events':sum(k['existing_scorable_event_count'] for k in keys),
             'added_operations':sum(len(c['operations_added']) for c in changes),
             'newly_planted_scorable_events':sum(k['newly_planted_event_count'] for k in keys),
             'total_weighted_events':sum(len(k['injections']) for k in keys),
             'files_changed':sum(bool(c['operations_added']) for c in changes),
             'families':dict(collections.Counter(e['family'] for k in keys for e in k['injections'])),
             'boundary_severities':dict(collections.Counter(e['severity'] for k in keys for e in k['injections'] if e['rule']=='boundary')),
             'group_weight_totals':{g:round(sum(e['weight'] for k in keys for e in k['injections'] if e['score_group']==g),6) for g in SHARES},
             'template_active_records':sum(k['status']=='ACTIVE' for k in kits),'template_injections':sum(len(k['injections']) for k in kits),
             'source_sha256':sha(source.read_bytes()),'not_applicable':['Devanagari has no letter case; G-CASE applies only to Latin code-switch tokens.',
                 'No Spanish-style accent dropping or contraction rules imposed on Hindi.',
                 'No synthetic checkbox errors planted: source has no trustworthy whole-audio synthetic flag.'],
             'limitations':['Supplied gold and duration are preserved as references, not acoustically verified.',
                 'Existing source-test overlaps are preserved; new errors introduce none.',
                 'Original source error labels/counts need auditing; small <=30 ms drifts are retained but not weighted.',
                 'Annotated gaps are not independently certified as silent. No audio supplied or generated.']}
    save(out/'summary.json',summary)
    export_tables(out,keys,audit_rows,changes,coverage)
    shutil.copy2(source,out/'original_hi_alignment_test_20.json')
    for name in ['alignment.py','build.py']:shutil.copy2(ROOT/name,out/name)
    return summary


def export_tables(out,keys,audits,changes,coverage):
    rows=[]
    for r in keys:
        for e in r['injections']:
            gs=e['gold_segments'];ts=e['test_segments']
            rows.append({'file_id':r['file_id'],'file_name':r['file_name'],'injection_id':e['injection_id'],'origin':e['origin'],
                         'family':e['family'],'score_group':e['score_group'],'band':e['band'],'weight':e['weight'],
                         'gold_indices':json.dumps(e['gold_indices']),'test_indices':json.dumps(e['test_indices']),
                         'gold_words':' | '.join(w['word'] for w in gs),'test_words':' | '.join(w['word'] for w in ts),
                         'gold_start':gs[0]['start'] if gs else None,'gold_end':gs[-1]['end'] if gs else None,
                         'test_start':ts[0]['start'] if ts else None,'test_end':ts[-1]['end'] if ts else None,
                         'edge':e.get('edge'),'shift_ms':e.get('shift_ms'),'severity':e.get('severity'),'fingerprint':e['fingerprint']})
    fields=list(rows[0])
    with (out/'answer_key.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    import openpyxl
    wb=openpyxl.Workbook();ws=wb.active;ws.title='Weighted answer key';ws.append(fields)
    for row in rows:ws.append([row[k] for k in fields])
    ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
    ws=wb.create_sheet('Existing error audit');headers=['file_id','original_entry_index','original_error_type','status','start_shift_ms','end_shift_ms','measured_max_delta_ms','measured_severity','above_30ms_scoring_tolerance','reason'];ws.append(headers)
    for r in audits:
        for a in r['original_entries']:
            v={'file_id':r['file_id'],**a,'original_error_type':a['original_entry']['error_type']};ws.append([v.get(k) for k in headers])
    ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
    ws=wb.create_sheet('Coverage');ws.append(['file_id','existing_families','final_families','added_families_or_severities','unavailable_types'])
    for r in coverage:ws.append([r['file_id']]+[json.dumps(r[k],ensure_ascii=False) for k in ['existing_families','final_families','added_families_or_severities','unavailable_types']])
    ws=wb.create_sheet('Weight rules');ws.append(['Group','Total points'])
    for g,v in SHARES.items():ws.append([g,v])
    ws.append(['Within each group: A1:A2:A3', '3:2:1']);wb.save(out/'answer_key.xlsx')


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,default=SOURCE);p.add_argument('--out',type=pathlib.Path,default=ROOT/'hindi_alignment_20')
    a=p.parse_args();print(json.dumps(build(a.source,a.out),ensure_ascii=False,indent=2))
