"""Monotone Hindi token/interval comparison and weighted reference-based scoring."""
import json
import math
import unicodedata

TOLERANCE_MS = 30


def norm(text):
    return unicodedata.normalize('NFC', text.strip())


def stamp(value):
    h, rem = divmod(round(value), 3600000)
    m, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    return f'{h:02d}:{m:02d}:{s:02d}.{ms:03d}'


def milliseconds(value):
    h, m, s = value.split(':')
    return round((int(h)*3600+int(m)*60+float(s))*1000)


def words(segments):
    return [{'word':s['transcription'], 's':milliseconds(s['startTime']), 'e':milliseconds(s['endTime'])} for s in segments]


def public(W):
    return [{'word':w['word'],'start':w['s']/1000,'end':w['e']/1000} for w in W]


def segments(W):
    return [{'segmentId':i,'startTime':stamp(w['s']),'endTime':stamp(w['e']),'transcription':w['word']} for i,w in enumerate(W,1)]


def align(gold, test):
    """Global minimum-edit alignment, using time proximity to disambiguate repeated words.

    Explicit merge transitions identify multiple gold tokens sharing a single test chip.
    """
    n,m=len(gold),len(test)
    costs=[[math.inf]*(m+1) for _ in range(n+1)]
    back=[[None]*(m+1) for _ in range(n+1)]
    costs[0][0]=0
    def offer(i,j,a,b,cost,action):
        if costs[i][j]+cost < costs[a][b]-1e-10:
            costs[a][b]=costs[i][j]+cost;back[a][b]=(i,j,action)
    for i in range(n+1):
        for j in range(m+1):
            if i<n:offer(i,j,i+1,j,1.1,'delete')
            if j<m:offer(i,j,i,j+1,1.1,'insert')
            if i<n and j<m:
                a,b=gold[i],test[j]
                distance=abs((a['s']+a['e'])-(b['s']+b['e']))/2
                same=norm(a['word'])==norm(b['word'])
                cost=(min(distance/1000,2)*.3 if same else 1.0+min(distance/250,3))
                offer(i,j,i+1,j+1,cost,'match')
                for size in range(2,min(6,n-i)+1):
                    span=gold[i:i+size]
                    texts={' '.join(w['word'] for w in span),''.join(w['word'].rstrip('.') for w in span)}
                    if norm(b['word']) in {norm(t) for t in texts}:
                        offer(i,j,i+size,j+1,.4,'merge')
    path=[];i,j=n,m
    while i or j:
        a,b,kind=back[i][j]
        path.append({'kind':kind,'gold_indices':list(range(a,i)),'test_indices':list(range(b,j))})
        i,j=a,b
    return list(reversed(path))


def severity(delta):
    d=abs(delta)
    if 40<=d<=80:return 'minor'
    if 100<=d<=300:return 'major'
    if d>300:return 'critical'
    return 'below_minor' if d<40 else 'between_minor_and_major'


def text_family(a,b):
    if norm(a).lower()==norm(b).lower() and norm(a)!=norm(b):return 'G-CASE'
    stripped=lambda x:''.join(c for c in norm(x) if unicodedata.category(c)[0]!='P')
    if stripped(a)==stripped(b):return 'G-PUNCT'
    if any(c.isdigit() for c in b) and not any(c.isdigit() for c in a):return 'G-NUM'
    # Devanagari vowel marks are phonemic; do not classify their removal as a punctuation/accent guideline.
    latin_a=any('LATIN' in unicodedata.name(c,'') for c in a)
    latin_b=any('LATIN' in unicodedata.name(c,'') for c in b)
    devan_a=any('DEVANAGARI' in unicodedata.name(c,'') for c in a)
    devan_b=any('DEVANAGARI' in unicodedata.name(c,'') for c in b)
    if (latin_a and devan_b and not devan_a) or (devan_a and latin_b and not devan_b):return 'G-SCRIPT'
    return 'WS'


def compare(gold,test):
    path=align(gold,test);events=[];diagnostics=[]
    for step in path:
        gs,ts=step['gold_indices'],step['test_indices']
        if step['kind']=='match':
            k,j=gs[0],ts[0];g,t=gold[k],test[j]
            if norm(g['word'])!=norm(t['word']):
                events.append({'family':text_family(g['word'],t['word']),'gold_indices':gs,'test_indices':ts,
                               'rule':'text','from':g['word'],'to':t['word']})
            for edge in ['s','e']:
                delta=t[edge]-g[edge]
                if not delta:continue
                e={'family':'BND-MINOR' if abs(delta)<=80 else 'BND-MAJOR','gold_indices':gs,'test_indices':ts,
                   'rule':'boundary','edge':'start' if edge=='s' else 'end','shift_ms':delta,'severity':severity(delta)}
                (events if abs(delta)>TOLERANCE_MS else diagnostics).append(e)
        elif step['kind']=='delete':events.append({'family':'WD','gold_indices':gs,'test_indices':[],'rule':'missing'})
        elif step['kind']=='insert':
            j=ts[0]
            following=next((x['gold_indices'][0] for x in path if x['test_indices'] and x['test_indices'][0]>j and x['gold_indices']),len(gold))
            events.append({'family':'WH','gold_indices':[],'test_indices':ts,'rule':'extra','inserted_before_index':following})
        else:
            family='SEG-LETTERS' if ' ' not in test[ts[0]]['word'] else 'SEG-MERGE'
            events.append({'family':family,'gold_indices':gs,'test_indices':ts,'rule':'merge'})
    return events,diagnostics,path


def band(event):
    if event['rule']=='boundary':return 'A1' if abs(event['shift_ms'])>300 else 'A3' if abs(event['shift_ms'])<100 else 'A2'
    return 'A1' if event['family'] in {'WD','WS'} else 'A2'


def score_record(key,candidate_segments):
    """Score each documented slot against the supplied reference, with a 30 ms boundary tolerance.

    Extra-over-speech chips are compared as unmatched test chips. This is distinct from the
    old reference scorer's silence-only WH detector, which cannot grade these existing examples.
    """
    gold=words(key['gold_source_segments']);candidate=words(candidate_segments)
    path=align(gold,candidate)
    matched={};extras=[];merged=[]
    for st in path:
        if st['kind']=='match':matched[st['gold_indices'][0]]=candidate[st['test_indices'][0]]
        elif st['kind']=='insert':extras.extend(candidate[i] for i in st['test_indices'])
        elif st['kind']=='merge':merged.append((st['gold_indices'],candidate[st['test_indices'][0]]))
    results=[]
    for event in key['injections']:
        kind=event['rule'];indices=event['gold_indices'];verdict='INDETERMINATE'
        if kind=='boundary':
            k=indices[0];got=matched.get(k)
            if got:
                edge='s' if event['edge']=='start' else 'e'
                delta=got[edge]-gold[k][edge]
                if abs(delta)<=TOLERANCE_MS:verdict='CAUGHT'
                elif abs(delta-event['shift_ms'])<=TOLERANCE_MS:verdict='MISSED'
        elif kind=='text':
            got=matched.get(indices[0])
            if got:
                verdict='CAUGHT' if norm(got['word'])==norm(event['from']) else 'MISSED' if norm(got['word'])==norm(event['to']) else 'INDETERMINATE'
        elif kind=='missing':
            got=matched.get(indices[0]);verdict='CAUGHT' if got and norm(got['word'])==norm(gold[indices[0]]['word']) else 'MISSED'
        elif kind=='extra':
            expected=event['test_segments'][0];a,b=round(expected['start']*1000),round(expected['end']*1000)
            still=any(norm(w['word'])==norm(expected['word']) and min(b,w['e'])-max(a,w['s'])>=.3*(b-a) for w in extras)
            verdict='MISSED' if still else 'CAUGHT'
        elif kind=='merge':
            restored=all(k in matched and norm(matched[k]['word'])==norm(gold[k]['word']) for k in indices)
            still=any(set(indices)==set(ks) for ks,w in merged)
            verdict='CAUGHT' if restored else 'MISSED' if still else 'INDETERMINATE'
        results.append({'injection_id':event['injection_id'],'family':event['family'],'weight':event['weight'],'verdict':verdict})
    total=sum(x['weight'] for x in results)
    return {'file_id':key['file_id'],'weighted_score_percent':round(100*sum(x['weight'] for x in results if x['verdict']=='CAUGHT')/total,4) if total else None,
            'injections':results,'note':'Additional errors not listed in this key require separate quality review.'}


if __name__=='__main__':
    import argparse,pathlib
    p=argparse.ArgumentParser(description='Score Hindi candidate alignments against the supplied weighted answer key.')
    p.add_argument('answer_key');p.add_argument('submissions',help='JSON list of {file_id, segments}, using startTime/endTime/transcription')
    a=p.parse_args();keys=json.loads(pathlib.Path(a.answer_key).read_text());submissions=json.loads(pathlib.Path(a.submissions).read_text())
    lookup={r['file_id']:r for r in submissions};out=[]
    for key in keys:
        if key['file_id'] in lookup:out.append(score_record(key,lookup[key['file_id']]['segments']))
    print(json.dumps(out,ensure_ascii=False,indent=2))
