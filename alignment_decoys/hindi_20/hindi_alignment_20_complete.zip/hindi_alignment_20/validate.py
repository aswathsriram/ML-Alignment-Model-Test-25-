"""Validate preservation, weighting, template restrictions, and functional Hindi scoring."""
import collections
import copy
import csv
import hashlib
import json
import pathlib
import random
import sys

from alignment import align,compare,public,score_record,segments,words
from build import event_identity


def read(path):return json.loads(path.read_text())
def overlap_pairs(W):
    return [(a['word'],a['s'],a['e'],b['word'],b['s'],b['e']) for a,b in zip(W,W[1:]) if a['e']>b['s']]


def validate(folder):
    original=read(folder/'original_hi_alignment_test_20.json')
    enriched=read(folder/'hi_alignment_test_20_enriched.json')
    keys=read(folder/'answer_key.json');summary=read(folder/'summary.json')
    changes=read(folder/'changes_added.json');audit=read(folder/'existing_error_audit.json')
    kits=read(folder/'decoy_corpus.json');supported=read(folder/'alignment_prefill_hi_IN_supported.json')['items']
    prefill=read(folder/'alignment_prefill_hi_IN.json')['items']
    assert len(original)==len(enriched)==len(keys)==len(changes)==len(audit)==len(kits['decoys'])==len(prefill)==20
    assert len(list((folder/'modified_transcripts').glob('*.json')))==20
    assert len({r['file_id'] for r in keys})==20 and len({r['audio_id'] for r in enriched})==20
    assert kits['format']=='align-decoy-kit/v1'
    allids=set();counts=collections.Counter();failures=[];groupweights=collections.Counter();rng=random.Random(20261105)
    for before,after,key,change,old_audit,kit,supported_item,full in zip(original,enriched,keys,changes,audit,kits['decoys'],supported,prefill):
        assert before['file_id']==after['file_id']==key['file_id']==change['file_id']==supported_item['id']==full['id']
        assert after['gold']==before['gold'] and after['n_words_gold']==len(before['gold']['segments'])
        assert after['original_answer_key']==before['answer_key']
        assert all(a['status']=='VERIFIED' for a in old_audit['original_entries'])
        assert len(old_audit['original_entries'])==len(before['answer_key'])==12
        G,T,R=words(before['gold']['segments']),words(before['test']['segments']),words(after['test']['segments'])
        assert all(0<=w['s']<w['e']<=round(after['duration_seconds']*1000) for w in R)
        assert overlap_pairs(T)==overlap_pairs(R),'Existing overlaps changed or new overlap introduced'
        inverted=lambda W:[(a['word'],a['s'],b['word'],b['s']) for a,b in zip(W,W[1:]) if a['s']>b['s']]
        assert inverted(T)==inverted(R),'A new out-of-order start was introduced or an inherited one was silently changed'
        old_events,old_diag,_=compare(G,T);new_events,new_diag,_=compare(G,R)
        assert {event_identity(e,G,T) for e in old_events}.issubset({event_identity(e,G,R) for e in new_events})
        assert {event_identity(e,G,T) for e in old_diag}.issubset({event_identity(e,G,R) for e in new_diag})
        changed={j for op in change['operations_added'] if op['action']!='insert' for j in op['test_indices']}
        revised_tuples=collections.Counter((w['word'],w['s'],w['e']) for w in R)
        unaffected=collections.Counter((w['word'],w['s'],w['e']) for j,w in enumerate(T) if j not in changed)
        assert all(revised_tuples[w]>=n for w,n in unaffected.items())
        assert public(R)==key['decoy_segments']==full['source']['words']
        assert full==read(folder/'modified_transcripts'/(key['file_id']+'.json'))
        assert after['answer_key']==key['injections'] and after['n_errors_seeded']==len(key['injections'])
        for e in key['injections']:
            assert e['injection_id'] not in allids;allids.add(e['injection_id'])
            assert e['weight']>0 and e['band'] in ['A1','A2','A3']
            groupweights[e['score_group']]+=e['weight']
            counts['preserved' if e['origin']=='preserved_input' else 'added']+=1
            if e['rule']=='boundary':
                g=G[e['gold_indices'][0]];w=R[e['test_indices'][0]];edge='s' if e['edge']=='start' else 'e'
                assert w[edge]-g[edge]==e['shift_ms']
        untouched=copy.deepcopy(after)
        # Root/source compatibility fields and their original claims remain available.
        for field in ['audio_id','file_id','duration_seconds','language','s3_path','n_words_gold','errors_from_real_ai','errors_invisible_to_a_human']:
            assert after[field]==before[field]
        a=score_record(key,after['test']['segments']);b=score_record(key,before['gold']['segments'])
        for x in a['injections']:
            counts['decoy_missed']+=x['verdict']=='MISSED'
            if x['verdict']!='MISSED':failures.append((key['file_id'],'decoy',x))
        for x in b['injections']:
            counts['gold_caught']+=x['verdict']=='CAUGHT'
            if x['verdict']!='CAUGHT':failures.append((key['file_id'],'gold',x))
        assert a['weighted_score_percent']==0 and b['weighted_score_percent']==100
        jitter=copy.deepcopy(G)
        for w in jitter:
            w['s']=max(0,w['s']+rng.randint(-20,20));w['e']+=rng.randint(-20,20)
            assert w['s']<w['e']
        j=score_record(key,segments(jitter))
        for x in j['injections']:
            counts['jitter_caught']+=x['verdict']=='CAUGHT'
            if x['verdict']!='CAUGHT':failures.append((key['file_id'],'jitter',x))
        # One actual boundary correction must produce a partial score, not all-or-nothing results.
        target=next(e for e in key['injections'] if e['rule']=='boundary')
        partial=copy.deepcopy(R);edge='s' if target['edge']=='start' else 'e'
        partial[target['test_indices'][0]][edge]=G[target['gold_indices'][0]][edge]
        score=score_record(key,segments(partial))
        assert 0<score['weighted_score_percent']<100
        counts['partial_correction_cases_passed']+=1
        assert kit['status']=='ACTIVE' and kit['locale']=='hi_IN' and kit['gold_segments']==public(G)
        occupied=set()
        for x in kit['injections']:
            assert x['family'] in ['BND-MAJOR','WD','WH','SEG-MERGE'] and x['weight']>0
            m=x['meta'];k=m.get('plain_offset')
            if x['family']=='BND-MAJOR':
                assert abs(m['shift_ms'])>=150
                assert round((m['decoy'][m['edge']]-public(G)[k][m['edge']])*1000)==m['shift_ms']
                used={k}
            elif x['family']=='WH':
                k=m['inserted_before_index'];assert 1<=k<len(G)
                assert G[k-1]['e']/1000<m['decoy']['start']<m['decoy']['end']<G[k]['s']/1000
                used={k-1,k}
            else:used={k,k+1} if x['family']=='SEG-MERGE' else {k}
            assert not occupied.intersection(used);occupied.update(used)
        SW=supported_item['source']['words']
        assert all(0<=w['start']<w['end']<=before['duration_seconds'] for w in SW)
        assert all(a['end']<=b['start'] for a,b in zip(SW,SW[1:]))
    assert counts['preserved']==summary['existing_scorable_events']
    assert counts['added']==summary['newly_planted_scorable_events']
    assert len(allids)==summary['total_weighted_events']
    assert not failures,failures[:5]
    for g,target in {'BOUNDARY':50,'MISSING':10,'HALLUCINATED':10,'WRONG-WORD':10,'SEGMENTATION':10,'GUIDELINE':10}.items():
        assert abs(groupweights[g]-target)<.00001
    with (folder/'answer_key.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f));assert len(rows)==len(allids) and {r['injection_id'] for r in rows}==allids
    import openpyxl
    wb=openpyxl.load_workbook(folder/'answer_key.xlsx',read_only=True)
    assert wb['Weighted answer key'].max_row==len(allids)+1
    assert wb['Existing error audit'].max_row==241;wb.close()
    report={'passed':True,'files':20,'original_entries_verified':240,'weighted_events':len(allids),**counts,
            'checks':['Gold and all original listed errors preserved','Unmodified test chips preserved exactly',
                      'Original 25 overlapping chip pairs and inherited out-of-order start preserved; no new invalid spans or ordering problems',
                      'All original timing diagnostics retained; <=30 ms drifts not weighted',
                      'Full and per-file output records agree; CSV and Excel agree',
                      'Group points sum to 50/10/10/10/10/10',
                      'All 20 template records active; only supported, non-conflicting injections',
                      'Supported subset prefill has no overlaps or zero-length spans',
                      'Gold/test, gold with +/-20ms jitter, and one-boundary partial-correction score controls pass'],
            'not_verified':['Audio content and silence','Acoustic accuracy of supplied gold','Platform import']}
    (folder/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':validate(pathlib.Path(sys.argv[1]))
