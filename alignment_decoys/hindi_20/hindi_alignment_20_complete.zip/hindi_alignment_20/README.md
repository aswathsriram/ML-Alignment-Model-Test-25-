# Hindi alignment test — audited and extended

20 existing clips. The original gold alignments, durations, filenames and 240 original answer-key entries are preserved. 104 additions fill missing applicable coverage, giving 405 weighted grading events (301 preexisting measured events + 104 new). The original count of 240 is not directly comparable: one listed timing error may move two edges, and the original test arrays contain additional timing differences. See `existing_error_audit.json` for all 240 source entries.

## Download / use

- `hi_alignment_test_20_enriched.json`: the original list-of-20 structure with enriched test data. Supplied gold is unchanged. `original_answer_key` preserves the original per-file entries; `answer_key` now contains the measured, weighted ledger. Original summary counters remain under `source_reported_counts`; the two original AI-origin/visibility claims are also retained unchanged at root for compatibility and are not newly verified claims.
- `alignment_prefill_hi_IN.json` and `modified_transcripts/`: full trainee-facing test data, including the existing errors and new additions. Keep gold and answer keys away from trainees.
- `answer_key.xlsx`, `answer_key.csv`, `answer_key.json`: weighted answer keys for the complete test. Each error has a stable ID, original/test slot evidence, band, weight, and preserved/new origin.
- `decoy_corpus.json`: uploaded `align-decoy-kit/v1` template format, 20 ACTIVE records and 98 supported injections. The compatible subset has its own weights and defines a different, smaller test.
- `alignment_prefill_hi_IN_supported.json`: only that compatible subset, reconstructed from gold. Use this with the template, not the full error mix.
- `changes_added.json`, `coverage_by_file.json`, `existing_error_audit.json`: exact additions, missing/not-applicable cases, and audit of original source entries.
- `original_hi_alignment_test_20.json`: the original uploaded file, byte-for-byte.
- `validation_report.json`: preservation and scoring evidence.

## Errors and preservation

The full set retains all preexisting substitutions, script normalization, punctuation, truncations, deletions, insertions and boundary shifts. Missing applicable types were added on untouched slots: 40–80 ms minor shifts, 100–300 ms major shifts, >300 ms critical shifts, missing chips, extra chips in annotated gaps, merged chips, Latin case errors, and Hindi spoken-number-to-digit errors. Letter merging is included where an actual spelled-letter sequence was available.

All 240 original answer-key values were verified against the supplied gold/test data. Informal names such as `boundary_small` are not used to determine severity: each edge delta is measured. Inherited shifts outside the requested ranges remain explicitly labelled `below_minor` or `between_minor_and_major`; no new shifts in those gaps were planted. The 45 source boundary differences at or below 30 ms are preserved as diagnostics and receive no error weight.

The 25 preexisting overlapping chip pairs (including one inverted-start pair) are preserved, not silently repaired. No new overlaps, reversed starts or non-positive spans were introduced. Devanagari vowel marks are phonemic: Spanish accent-dropping rules are not imposed on Hindi. Case errors affect only Latin code-switch tokens. Synthetic checkbox errors are not invented without a trusted source flag. Some short token patterns or safe gaps are unavailable in individual files; the coverage manifest lists these.

## Weights and grading

Across the full corpus, BOUNDARY receives 50 points; MISSING, HALLUCINATED, WRONG-WORD, SEGMENTATION and GUIDELINE receive 10 points each. Within each group A1:A2:A3 has factor 3:2:1. Each exact numeric weight is in the answer key. Aggregate score = 100 × sum of caught weights / sum of attempted weights. Per-file scores normalize that file's own denominator; averaging them is not the same as the corpus-weighted aggregate.

`alignment.py` provides a Hindi-specific paired-reference scorer. It uses token order plus timing to distinguish repeated words, supports extra words placed over speech (present in this source), and uses a 30 ms boundary correction tolerance. It is not the old Spanish JS scorer, whose silence-only extra-chip rule cannot grade all these inherited Hindi examples. Additional unlisted errors in a submission require separate quality review.

To score candidate submissions, provide a JSON list of `{file_id, segments}` with `transcription`, `startTime`, and `endTime` fields per segment, then run:

```
python3 alignment.py answer_key.json submissions.json > scores.json
```

Validation passed 405/405 unchanged-decoy checks, 405/405 gold-reference checks, 405/405 gold-with-±20 ms-jitter checks, and 20 partial-boundary-correction controls. Recheck with `python3 validate.py .`.

To reproduce, install `requirements-reproduce.txt`, then run `python3 build.py --source original_hi_alignment_test_20.json --out rebuild`. The builder uses the provided `uploaded_template.json` when run from this package. The full and template outputs are different tests; keep their answer keys paired appropriately.

No audio was supplied or generated. Gold, duration and language conventions are accepted from the supplied file, not acoustically verified. Annotated gaps are not certified as silence. Platform import has not been tested; add the matching audio when using the template kit importer.
