Import decoy_corpus.json and audio/ together using align-decoy-kit/v1. There are 20 audio files and 20 matching plain-text transcripts.
gold_segments holds correct alignment; injections describes deliberate timing errors. Do not correct the planted errors.
All source audio is synthesized: 17 natural-sounding and 3 robotic-style clips. gold_whole_audio_tag is none for import compatibility, as in the GitHub workflow. See provenance.json.
Japanese and Chinese exclude SEG-MERGE per the uploaded template. The boundary group receives 50 total weight points; other present families divide the remaining 50 equally.
Audio/transcript checks are structural, not a listening review or proof of successful platform import.
