# Spanish alignment decoys — 297 supplied records

## Files
- `alignment_prefill_es_ES.json`: combined trainee-facing machine prefill.
- `modified_transcripts/`: one trainee-facing JSON per original record (297 files).
- `modified_deliveries/`: original delivery schema with only the selected answer changed. Other annotator answers remain for traceability; do not show these history files to trainees as they contain unmodified reference answers. Original inputData is preserved.
- `decoy_corpus.json`: uploaded align-decoy-kit/v1 format, all records; only ACTIVE records are eligible for import.
- `decoy_corpus_ACTIVE_ONLY.json`: same template, active records only (111).
- `answer_key.json`, `decoy_corpus_ALL.csv`, `decoy_corpus_CHANGED.csv`, `answer_key.xlsx`: answer keys, including original/modified words, offsets, changes in milliseconds, reasons, and source pointers. Keep these server-side.
- `original_deliveries/`: original JSON bytes, retained unchanged.
- `file_manifest.json`, `summary.json`, `validation_report.json`: complete accounting and limitations.
- `reference_tools/`: unchanged scorer, self-test and guideline PDF from the supplied reference ZIP. The old scorer is supplied as a reference; the platform template and this build's exact-diff validation are separate checks.

## Counts and interpretation
297 records contain planted errors; 0 could not be modified in this mode. Every one of the 297 input records is present and accounted for.
Mode: `full`. Boundary severity: minor 40–80 ms; major 100–300 ms; critical above 300 ms. Template imports retain only boundary shifts at least 150 ms and WD/WH/SEG-MERGE. Any other selected errors remain in the prefill and full answer key, not the template injections.

No new zero-length spans or overlaps are planted. The reference package's BND-ZERO and BND-OVERLAP cases are deliberately not copied: the agreed timing edits retain positive spans and introduce no new overlaps. Existing source overlaps are retained in the reference and never silently normalised. Multiple error types are spread over distinct word positions where possible. Short clips cannot contain every family or every boundary severity; available and selected groups are listed per record. Accent-dropping errors are not planted where the supplied reference has no accented tokens to remove.

Boundary shifts have signed integer millisecond deltas in each injection. A1/A2/A3 weights are explicitly 3/2/1 in this build; these are recorded per injection and are not a claim that group totals match the old 20-file package. The unchanged scorer supports the answer-key array: run `node reference_tools/run_selftest.js answer_key.json`. Do not give the template object to that old array-based runner. The full prefill and the template-supported subset intentionally define different tests: minor shifts and text-changing errors appear only in the full test. Keep the matching answer key with each.

`gold_segments` means the selected supplied reference: adjudication where available, otherwise the latest timestamped blind-pass answer. The other blind-pass is not arbitrarily merged with it. This is an assumed reference, not independent proof of correctness.

No matching audio was supplied. The 20 WAVs in the example ZIP are reference examples, not the audio for these records, and are not relabelled or included. Supply the matching audio before using an audio-import kit. `duration_seconds` is the maximum supplied input/final alignment end, a conservative lower bound rather than a measured duration. Timing edits stay inside that known bound; replace it with the actual measured duration before production import.

WH additions lie strictly within an annotated gap. Without audio, that gap cannot be certified as acoustically silent. Source synthetic flags are preserved in the reference. Full mode can deliberately hide that checkbox and records it as CB-WHOLE; these synthetic records remain INACTIVE in the template because that importer skips them.

## Reproduction
`python3 build.py --mode full --delivery PATH_TO_DELIVERY_ZIP --template PATH_TO_TEMPLATE_JSON --reference PATH_TO_REFERENCE_ZIP --out OUTPUT_DIRECTORY`
The builder uses the Python standard library plus openpyxl for the Excel answer key. Run `python3 validate.py OUTPUT_DIRECTORY` after building. No API key or audio API is used.
