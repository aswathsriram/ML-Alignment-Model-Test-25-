"""Independent file-accounting and exact-diff validation of a completed build."""
import collections
import copy
import csv
import hashlib
import json
import pathlib
import sys


def load(path):
    return json.loads(path.read_text())


def canonical(obj):
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()


def pointer(document,path):
    obj=document
    for part in path.strip('/').split('/'):
        part=part.replace('~1','/').replace('~0','~')
        obj=obj[int(part)] if isinstance(obj,list) else obj[part]
    return obj


def tms(text):
    h,m,s=text.split(':')
    return round((int(h)*3600+int(m)*60+float(s))*1000)


def main(folder):
    keys=load(folder/'answer_key.json')
    prefill=load(folder/'alignment_prefill_es_ES.json')
    template=load(folder/'decoy_corpus.json')
    active=load(folder/'decoy_corpus_ACTIVE_ONLY.json')
    summary=load(folder/'summary.json')
    assert len(keys)==len(prefill['items'])==len(template['decoys'])==summary['source_workitems']==297
    assert prefill['fileMetadata']['workitemsCount']==297
    assert template['format']==active['format']=='align-decoy-kit/v1'
    assert active['decoys']==[r for r in template['decoys'] if r['status']=='ACTIVE']
    originals={p.name:load(p) for p in (folder/'original_deliveries').glob('*.json')}
    modified={p.name:load(p) for p in (folder/'modified_deliveries').glob('*.json')}
    restored=copy.deepcopy(modified)
    records={r['id']:r for r in prefill['items']}
    assert len(records)==297
    assert len(list((folder/'modified_transcripts').glob('*.json')))==297
    all_ids=set(); expected_injections=0; template_count=0; boundary_counts=collections.Counter()
    for key, kit in zip(keys,template['decoys']):
        item=records[key['file_id']]
        assert load(folder/'modified_transcripts'/(key['file_id']+'.json'))==item
        assert item['source']['words']==key['decoy_segments']
        assert item['transcript']==key['decoy_text'] and item['whole_audio_tag']==key['decoy_whole_audio_tag']
        assert kit['decoy_id']==key['decoy_id'] and kit['gold_segments']==key['gold_segments']
        assert key['injections'] and key['injection_count']==len(key['injections'])
        expected_injections+=len(key['injections'])
        original=pointer(originals[key['source_document']],key['source_answer_json_pointer'])
        assert original==key['source_answer_original']
        assert hashlib.sha256(canonical(original)).hexdigest()==key['source_answer_sha256']
        gold=[{'word':w['final_transcription'],'start':tms(w['final_startTime'])/1000,'end':tms(w['final_endTime'])/1000} for w in original['segments']]
        assert gold==key['gold_segments']
        altered=pointer(modified[key['source_document']],key['source_answer_json_pointer'])
        assert altered!=original
        assert len(altered['segments'])==altered['final_n_total_segments']==len(key['decoy_segments'])
        assert altered['final_full_transcript']==key['decoy_text']
        assert altered['audio_synthetic']==(key['decoy_whole_audio_tag']=='synthetic_speech')
        converted=[{'word':w['final_transcription'],'start':tms(w['final_startTime'])/1000,'end':tms(w['final_endTime'])/1000} for w in altered['segments']]
        assert converted==key['decoy_segments']
        target=pointer(restored[key['source_document']],key['source_answer_json_pointer'])
        target.clear();target.update(copy.deepcopy(original))
        assert key['gold_segments']!=key['decoy_segments'] or key['gold_whole_audio_tag']!=key['decoy_whole_audio_tag']
        before_overlap=sum(a['end']>b['start'] for a,b in zip(gold,gold[1:]))
        decoy=key['decoy_segments']
        assert sum(a['end']>b['start'] for a,b in zip(decoy,decoy[1:]))<=before_overlap
        assert all(0<=w['start']<w['end']<=key['duration_seconds'] for w in decoy)
        used=set()
        for op in key['operations']:
            positions=set(op['affected']);assert not positions.intersection(used);used.update(positions)
            assert all(any(c.isalnum() for c in gold[k]['word']) and not gold[k]['word'].startswith(('[','<')) for k in positions)
        for inj in key['injections']:
            assert inj['injection_id'] not in all_ids;all_ids.add(inj['injection_id'])
            assert inj['weight']>0 and inj['band'] in {'A1','A2','A3'} and inj.get('fingerprint')
            m=inj.get('meta',{})
            if inj['family'].startswith('BND-'):
                w=gold[m['plain_offset']]
                delta=round(1000*(m['decoy'][m['edge']]-w[m['edge']]))
                assert delta==m['shift_ms'] and delta!=0
                magnitude=abs(delta)
                assert (40<=magnitude<=80 if m['severity']=='minor' else 100<=magnitude<=300 if m['severity']=='major' else magnitude>300)
                boundary_counts[m['severity']]+=1
            elif inj['family']=='WH':
                k=m['inserted_before_index'];assert 1<=k<len(gold)
                assert gold[k-1]['end']<m['decoy']['start']<m['decoy']['end']<gold[k]['start']
                assert m['audio_silence_verified'] is False
            elif inj['family']=='CB-WHOLE':
                assert not gold and original['audio_synthetic'] is True
                assert key['decoy_whole_audio_tag']=='none'
        assert set(key['template_injection_ids'])=={i['injection_id'] for i in kit['injections']}
        for inj in kit['injections']:
            assert inj['family'] in {'BND-MAJOR','WD','WH','SEG-MERGE'}
            if inj['family']=='BND-MAJOR':assert abs(inj['meta']['shift_ms'])>=150
        if kit['status']=='ACTIVE':
            template_count+=1
            assert len(gold)>=8 and not key['source_issues'] and kit['gold_whole_audio_tag']=='none'
            assert kit['injections'] and any(i['band']=='A1' for i in kit['injections'])
            assert not key['template_exclusion_reasons']
        else:assert key['template_exclusion_reasons']
    # Replacing only the modified selected answers must exactly restore both source documents.
    assert restored==originals
    assert expected_injections==summary['total_injections']
    assert dict(boundary_counts)==summary['boundary_severities']
    assert template_count==summary['template_active_records']==len(active['decoys'])
    with (folder/'decoy_corpus_ALL.csv').open(encoding='utf-8-sig',newline='') as f:
        csv_rows=list(csv.DictReader(f))
    assert len(csv_rows)==expected_injections and {r['file_id'] for r in csv_rows}==set(records)
    assert {r['injection_id'] for r in csv_rows}==all_ids
    import openpyxl
    wb=openpyxl.load_workbook(folder/'answer_key.xlsx',read_only=True)
    assert wb['Injections'].max_row==expected_injections+1 and wb['All records'].max_row==298
    wb.close()
    report={'passed':True,'source_records':297,'modified_records':297,'injections_verified':expected_injections,
            'active_template_records':template_count,'boundary_counts':dict(boundary_counts),
            'checks':['All source IDs accounted for; no duplicates or unmatched output records',
                      'Every one of 297 records has a documented planted change',
                      'Full selected source answer snapshots and SHA256 digests match originals',
                      'Only selected source answers changed; replacing them restores both source documents exactly',
                      'Per-record, combined prefill, modified delivery, answer-key and CSV/Excel outputs agree',
                      'No new overlaps, negative starts or zero-length spans',
                      'Boundary shifts independently recomputed in milliseconds; severity ranges checked',
                      'WH additions strictly inside supplied annotation gaps',
                      'Template includes only supported errors; active records meet eligibility rules'],
            'not_checked':['Actual speech timing/silence','Actual audio duration','Platform import']}
    (folder/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main(pathlib.Path(sys.argv[1]))
