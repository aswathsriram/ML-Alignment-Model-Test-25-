"""Build deterministic Spanish alignment decoys from reviewed delivery JSONs.

The uploaded documents supply schema/reference data only. This program never fetches audio.
"""
import argparse
import collections
import copy
import csv
import hashlib
import json
import pathlib
import random
import re
import shutil
import zipfile
from decimal import Decimal

ROOT = pathlib.Path(__file__).resolve().parent
DEFAULT_DELIVERY = pathlib.Path('/workspace/attachments/497925da-6e9e-4426-8464-28cc40d9e8f5/forced-alignment-deliveries-2026-11-04-07-50.zip')
DEFAULT_TEMPLATE = pathlib.Path('/workspace/attachments/be9a4a70-aba2-4d37-b13a-9f591d303911/decoy_corpus.template (1).json')
DEFAULT_REFERENCE = pathlib.Path('/workspace/attachments/6b9e8a71-885c-44ca-a7c6-492bdcfc0ff6/alignment_decoys_es_ES-20261104T075357Z-1-001.zip')
SUPPORTED = {'BND-MAJOR', 'WD', 'WH', 'SEG-MERGE'}
SEED = 'es-deliveries-20261104-v1'
NUMBER = dict(zip('cero uno dos tres cuatro cinco seis siete ocho nueve diez once doce trece catorce quince dieciséis diecisiete dieciocho diecinueve veinte treinta cuarenta cincuenta sesenta setenta ochenta noventa cien'.split(),
                  ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','30','40','50','60','70','80','90','100']))
OPPOSITES = dict(zip('sí no uno dos tres cuatro cinco hoy mañana ayer aquí allí izquierda derecha arriba abajo antes después'.split(),
                     'no sí dos tres cuatro cinco seis mañana ayer hoy allí aquí derecha izquierda abajo arriba después antes'.split()))
FILLERS = {'eh','ah','este','mmm','mm','hum','bueno','pues'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(encoded(obj))


def millis(text):
    h, m, s = text.split(':')
    return int(h) * 3600000 + int(m) * 60000 + int(Decimal(s) * 1000)


def timestamp(value):
    h, rem = divmod(value, 3600000)
    m, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    return f'{h:02d}:{m:02d}:{s:02d}.{ms:03d}'


def public_words(words):
    return [{'word': w['word'], 'start': w['s'] / 1000, 'end': w['e'] / 1000} for w in words]


def protected(word):
    return word.startswith(('[', '<')) or not any(c.isalnum() for c in word)


def load_records(delivery):
    rows, documents = [], {}
    with zipfile.ZipFile(delivery) as z:
        assert z.testzip() is None
        for name in sorted(z.namelist()):
            assert pathlib.PurePosixPath(name).name == name and name.endswith('.json')
            document = json.loads(z.read(name))
            documents[name] = document
            assert document['fileMetadata']['workitemsCount'] == len(document['workitems'])
            for ix, item in enumerate(document['workitems']):
                assert item['locale'] == 'es_ES'
                choices = []
                for key, value in item.items():
                    if not isinstance(value, list):
                        continue
                    for ti, task in enumerate(value):
                        if not isinstance(task, dict) or not isinstance(task.get('data'), dict):
                            continue
                        for ai, answer in enumerate(task['data'].get('taskAnswers', [])):
                            if 'segments' in answer:
                                meta = task.get('metadata', {})
                                pointer = ['workitems', ix, key, ti, 'data', 'taskAnswers', ai]
                                choices.append((meta, answer, pointer))
                adjudicated = [c for c in choices if c[0].get('operationType') == 'ADJUDICATION']
                assert choices, f'No answers for {item["workItemId"]}'
                meta, answer, pointer = max(adjudicated or choices, key=lambda c: (c[0].get('labelledTimestamp', ''), str(c[2])))
                words = [{'word': s['final_transcription'], 's': millis(s['final_startTime']), 'e': millis(s['final_endTime']), 'source_segment_id': s['final_segmentId']}
                         for s in answer['segments']]
                issues = []
                if any(w['s'] < 0 or w['s'] >= w['e'] for w in words):
                    issues.append('invalid_source_span')
                if any(a['s'] > b['s'] for a, b in zip(words, words[1:])):
                    issues.append('source_out_of_order')
                if any(a['e'] > b['s'] for a, b in zip(words, words[1:])):
                    issues.append('source_overlap')
                observed = [w['e'] for w in words] + [millis(s['endTime']) for s in item['inputData'].get('segments', [])]
                bound = max(observed, default=0)
                audio = answer.get('ref_audio') or item['inputData'].get('ref_audio', '')
                rows.append({'id': item['workItemId'], 'name': pathlib.PurePosixPath(audio).name,
                             'source_document': name, 'answer_path': pointer, 'selection': {
                                 'method': 'adjudication' if adjudicated else 'latest_blindpass',
                                 'timestamp': meta.get('labelledTimestamp'), 'candidate_count': len(choices),
                                 'assumed_reference_not_audio_verified': True},
                             'words': words, 'transcript': answer.get('final_full_transcript', ''),
                             'synthetic': bool(answer.get('audio_synthetic')), 'multiple_speakers': bool(answer.get('multiple_speakers')),
                             'overlapping_speech': bool(answer.get('overlapping_speech')), 'answer': answer,
                             'bound_ms': bound, 'source_issues': issues})
    assert len({r['id'] for r in rows}) == len(rows)
    assert len({r['name'] for r in rows}) == len(rows)
    return rows, documents


def candidates(row, mode):
    words, bound = row['words'], row['bound_ms']
    result = []

    def add(family, band, k, indices, action, **payload):
        result.append({'family': family, 'band': band, 'k': k, 'affected': list(indices), 'action': action, **payload})

    for k, w in enumerate(words):
        text = w['word']
        if protected(text) or w['e'] <= w['s']:
            continue
        add('WD', 'A1' if len(text) >= 4 else 'A2', k, [k], 'delete')
        for edge in ['s', 'e']:
            for shift in ([-80,-70,-60,-50,-40,40,50,60,70,80,-100,-120,-140,100,120,140] if mode == 'full' else []) + [-600,-500,-450,-400,-350,-320,-300,-250,-200,-180,-150,150,180,200,250,300,320,350,400,450,500,600]:
                a, b = w['s'], w['e']
                if edge == 's':
                    a += shift
                else:
                    b += shift
                previous = words[k - 1]['e'] if k else 0
                following = words[k + 1]['s'] if k + 1 < len(words) else bound
                if a < max(0, previous) or b > min(bound, following) or b - a < 30:
                    continue
                magnitude = abs(shift)
                family = 'BND-MINOR' if magnitude <= 80 else 'BND-MAJOR'
                severity = 'minor' if magnitude <= 80 else 'major' if magnitude <= 300 else 'critical'
                add(family, {'minor': 'A3', 'major': 'A2', 'critical': 'A1'}[severity], k, [k], 'boundary',
                    edge='start' if edge == 's' else 'end', shift_ms=shift, new_s=a, new_e=b, severity=severity)
        if mode == 'full':
            replacement = OPPOSITES.get(text.lower(), 'mañana' if text.lower() != 'mañana' else 'ayer')
            add('WS', 'A1', k, [k], 'text', replacement=replacement, rule='word_substituted')
            if text.islower() and text[0].isalpha():
                add('G-CASE', 'A2', k, [k], 'text', replacement=text[0].upper() + text[1:], rule='capitalisation_inserted')
            if text in NUMBER:
                add('G-NUM', 'A1', k, [k], 'text', replacement=NUMBER[text], rule='digits_for_number_word')
            unaccented = text.translate(str.maketrans('áéíóúÁÉÍÓÚ', 'aeiouAEIOU'))
            if text != unaccented:
                add('G-ACCENT', 'A3', k, [k], 'text', replacement=unaccented, rule='accent_dropped')
            if text[-1:].isalnum():
                add('G-PUNCT', 'A2', k, [k], 'text', replacement=text + ',', rule='punctuation_in_segment')
            if text in {'al', 'del'} and w['e'] - w['s'] >= 80:
                add('G-CONTRACT', 'A2', k, [k], 'split', pieces=['a', 'el'] if text == 'al' else ['de', 'el'], rule='contraction_written_out')
            if text in {'claro', 'vale', 'bueno'}:
                add('G-BACKCH', 'A3', k, [k], 'text', replacement=text[0] + text, rule='backchannel_misspelt')
        if k + 1 < len(words) and not protected(words[k + 1]['word']):
            nxt = words[k + 1]
            if nxt['s'] >= w['e']:
                add('SEG-MERGE', 'A2', k, [k,k+1], 'merge')
                if mode == 'full' and text.lower() in FILLERS and text.lower() != nxt['word'].lower():
                    add('SEG-FILLER', 'A2', k, [k,k+1], 'filler')
            gap = nxt['s'] - w['e']
            if gap >= 200:
                middle = (nxt['s'] + w['e']) // 2
                half = min(120, (gap - 80) // 2)
                if half >= 40:
                    add('WH', 'A2', k + 1, [k,k+1], 'insert', insertion_word=text,
                        new_s=middle-half, new_e=middle+half, gap_ms=gap)
        if mode == 'full' and re.fullmatch(r'[a-záéíóúüñ]\.?' , text.lower()):
            stop = k + 1
            while stop < len(words) and re.fullmatch(r'[a-záéíóúüñ]\.?' , words[stop]['word'].lower()) and words[stop]['s'] >= words[stop-1]['e']:
                stop += 1
            if stop - k >= 2:
                add('SEG-LETTERS', 'A2', k, list(range(k, stop)), 'letters')
    return result


def group(c):
    if c['family'].startswith('BND-'):
        return c['severity']
    return c['family']


def choose(row, mode, position):
    cs = candidates(row, mode)
    if not cs:
        return [], cs
    target = min(6, max(1, 1 + len(row['words']) // 4))
    # Prefer a mix, with long records gaining several different error families.
    priorities = (['minor','major','critical','WD','WH','WS','SEG-MERGE','G-NUM','G-ACCENT','G-CASE','G-PUNCT','G-CONTRACT','SEG-FILLER','G-BACKCH','SEG-LETTERS']
                  if mode == 'full' else ['major','critical','WD','WH','SEG-MERGE'])
    rotation = position % len(priorities)
    priorities = priorities[rotation:] + priorities[:rotation]
    best, best_score = [], -1
    for spacing in [3, 2, 1]:
        for attempt in range(8):
            rng = random.Random(f'{SEED}:{row["id"]}:{spacing}:{attempt}')
            pool = list(cs)
            rng.shuffle(pool)
            picked, occupied = [], set()
            # One candidate per priority family before any family repeats.
            for wanted in priorities:
                eligible = [c for c in pool if group(c) == wanted and all(abs(a-b) >= spacing for a in c['affected'] for b in occupied)]
                if eligible:
                    c = eligible[0]
                    picked.append(copy.deepcopy(c)); occupied.update(c['affected'])
                if len(picked) >= target:
                    break
            if len(picked) < target:
                for c in pool:
                    if all(abs(a-b) >= spacing for a in c['affected'] for b in occupied):
                        picked.append(copy.deepcopy(c)); occupied.update(c['affected'])
                    if len(picked) >= target:
                        break
            score = len(picked) * 1000 + len({group(c) for c in picked}) * 50 + spacing
            if score > best_score:
                best, best_score = picked, score
        if len(best) >= target:
            break
    best.sort(key=lambda c: (c['k'], c['action']))
    if len(row['words']) >= 8 and not any(c['family'] in SUPPORTED and (c['action'] != 'boundary' or abs(c['shift_ms']) >= 150) for c in best):
        # Ensure the compatible subset has an actual supported error for each sufficiently long record.
        # Replace one single-word unsupported edit at the same position; other chosen positions stay distinct.
        for i, op in enumerate(best):
            replacement = next((c for c in cs if c['family'] == 'WD' and c['k'] == op['k']), None)
            if replacement:
                best[i] = copy.deepcopy(replacement)
                break
    return best, cs


def apply(words, operations):
    result, by_index, insertions = [], {}, {}
    for op in operations:
        if op['action'] == 'insert':
            insertions[op['k']] = op
        else:
            by_index[op['k']] = op
    k = 0
    while k < len(words):
        if k in insertions:
            op = insertions[k]
            result.append({'word': op['insertion_word'], 's': op['new_s'], 'e': op['new_e']})
        w = copy.deepcopy(words[k])
        op = by_index.get(k)
        if not op:
            result.append(w); k += 1; continue
        action = op['action']
        if action == 'boundary':
            w.update(s=op['new_s'], e=op['new_e']); result.append(w)
        elif action == 'delete':
            pass
        elif action == 'text':
            w['word'] = op['replacement']; result.append(w)
        elif action in {'merge','filler','letters'}:
            span = [words[i] for i in op['affected']]
            text = (' '.join(x['word'] for x in span) if action == 'merge' else span[-1]['word'] if action == 'filler' else ''.join(x['word'].rstrip('.') for x in span))
            result.append({'word': text, 's': span[0]['s'], 'e': span[-1]['e']})
            k = max(op['affected']) + 1; continue
        elif action == 'split':
            mid = (w['s'] + w['e']) // 2
            result.extend([{'word':op['pieces'][0], 's':w['s'], 'e':mid}, {'word':op['pieces'][1], 's':mid, 'e':w['e']}])
        else:
            raise AssertionError(action)
        k += 1
    return result


def injection(row, op, index):
    words, k = row['words'], op['k']
    word = words[k]
    meta = {'plain_offset': k, 'left': ' '.join(w['word'] for w in words[max(0,k-5):k]),
            'right': ' '.join(w['word'] for w in words[k+1:k+6]), 'gold': public_words([word])[0]}
    meta['gold'].pop('word')
    action = op['action']
    if action == 'boundary':
        meta.update(word=word['word'], edge=op['edge'], shift_ms=op['shift_ms'], severity=op['severity'],
                    direction='early' if op['shift_ms']<0 else 'late',
                    decoy={'start':op['new_s']/1000,'end':op['new_e']/1000},
                    rule=op['edge']+'_'+('early' if op['shift_ms']<0 else 'late'), detect='EDGE_AT_SLOT')
    elif action == 'delete':
        meta.update(word=word['word'], rule='word_deleted', detect='WORD_AT_SLOT_PRESENT')
    elif action == 'insert':
        meta.update(word=op['insertion_word'], inserted_before_index=k,
                    decoy={'start':op['new_s']/1000,'end':op['new_e']/1000},
                    rule='extra_chip_in_annotated_gap', detect='SEGMENT_AT_SLOT_ABSENT',
                    gap_ms=op['gap_ms'], audio_silence_verified=False)
    elif action == 'text':
        meta.update({'from':word['word'], 'to':op['replacement'], 'rule':op['rule'], 'detect':'WORD_AT_SLOT_SUBSTITUTED'})
    elif action in {'merge','letters'}:
        parts = public_words([words[i] for i in op['affected']])
        meta.update(parts=parts, joined=' '.join(p['word'] for p in parts) if action=='merge' else ''.join(p['word'].rstrip('.') for p in parts),
                    gold={'start':parts[0]['start'],'end':parts[-1]['end']}, rule='two_words_one_segment' if action=='merge' else 'letters_joined', detect='WORDS_SPLIT')
    elif action == 'split':
        mid=(word['s']+word['e'])//2
        meta.update(word=word['word'], pieces=[{'word':op['pieces'][0],'start':word['s']/1000,'end':mid/1000},{'word':op['pieces'][1],'start':mid/1000,'end':word['e']/1000}],
                    rule=op['rule'],detect='WORD_MERGED')
    elif action == 'filler':
        nxt=words[k+1]
        meta.update(word=word['word'],next_word=nxt['word'],next_gold={'start':nxt['s']/1000,'end':nxt['e']/1000},
                    decoy_next={'start':word['s']/1000,'end':nxt['e']/1000},rule='filler_inside_next_word',detect='FILLER_PRESENT')
    inj = {'injection_id':f'{row["decoy_id"]}-{index}', 'family':op['family'], 'band':op['band'],
           'weight':{'A1':3.0,'A2':2.0,'A3':1.0}[op['band']], 'meta':meta}
    inj['fingerprint']=digest(canonical(inj))[:16]
    return inj


def template_record(row, operations, instructions):
    reasons=[]
    if len(row['words']) < 8:reasons.append('fewer_than_8_gold_words')
    if row['synthetic']:reasons.append('synthetic_speech_skipped_by_importer')
    reasons.extend(row['source_issues'])
    accepted = [copy.deepcopy(x) for x in row['injections'] if x['family'] in SUPPORTED and (x['family']!='BND-MAJOR' or abs(x['meta']['shift_ms'])>=150)]
    if not accepted:reasons.append('no_template_supported_injections')
    if row['bound_ms'] > 360000:reasons.append('observed_alignment_bound_over_6_minutes')
    if not reasons and not any(x['band']=='A1' for x in accepted):
        # A1 is an importance label, independent of boundary severity. Promote the highest-weight error, documenting it.
        top=max(accepted,key=lambda x:(x['weight'],abs(x.get('meta',{}).get('shift_ms',0))))
        top['band']='A1';top['weight']=3.0
        top['meta']['note']='Highest-priority supported error for this clip; boundary severity remains in meta.severity.'
    return {'decoy_id':row['decoy_id'],'locale':'es_ES','file_name':row['name'],
            'duration_seconds':row['bound_ms']/1000,'status':'INACTIVE' if reasons else 'ACTIVE',
            'gold_whole_audio_tag':'synthetic_speech' if row['synthetic'] else 'none',
            'gold_segments':public_words(row['words']),'injections':accepted}, reasons


def build(mode, delivery, template, reference, out):
    rows, documents = load_records(delivery)
    out.mkdir(parents=True,exist_ok=True)
    original_documents=copy.deepcopy(documents)
    template_instructions=json.loads(template.read_text())['instructions']
    corpus, full_key, prefill, catalog=[],[],[],[]
    for position,row in enumerate(rows):
        row['decoy_id']='ES-DELIVERY-'+row['id']+'-'+digest(canonical(public_words(row['words'])))[:8]
        operations,available=choose(row,mode,position)
        decoy=apply(row['words'],operations)
        row['injections']=[injection(row,op,i) for i,op in enumerate(operations,1)]
        if mode=='full' and row['synthetic']:
            row['injections'].append({'injection_id':row['decoy_id']+'-whole-audio','family':'CB-WHOLE','band':'A1','weight':3.0,
                                     'field':'whole_audio_tag','gold':'synthetic_speech','decoy':'none',
                                     'detect':'CHECKBOX_WHOLE_AUDIO','rule':'entirely_synthetic_not_marked','audio_required':True,
                                     'basis':'source_annotation_flag_not_independently_audio_verified'})
        for inj in row['injections']:
            if 'fingerprint' not in inj:
                inj['fingerprint']=digest(canonical(inj))[:16]
        if not row['injections']:
            reason='no_final_word_timings' if not row['words'] else 'no_safe_edit_available'
        else:reason=None
        decoy_tag='none' if any(x['family']=='CB-WHOLE' for x in row['injections']) else 'synthetic_speech' if row['synthetic'] else 'none'
        # WD leaves the original full transcript intact while its timing chip disappears.
        deleted={op['k'] for op in operations if op['action']=='delete'}
        text_words=apply(row['words'],[op for op in operations if op['action']!='delete'])
        text=' '.join(w['word'] for w in text_words) if any(op['action'] in {'text','split','letters','filler','insert'} for op in operations) else row['transcript']
        record={'id':row['id'],'name':row['name'],'locale':'es_ES','transcript':text,
                'source':{'duration_seconds':row['bound_ms']/1000,'duration_basis':'max_supplied_alignment_end_lower_bound_not_measured_audio_duration','words':public_words(decoy)},
                'whole_audio_tag':decoy_tag}
        prefill.append(record)
        write_json(out/'modified_transcripts'/(row['id']+'.json'),record)
        t,reasons=template_record(row,operations,template_instructions)
        corpus.append(t)
        key={'decoy_id':row['decoy_id'],'group':'AL-SYNTHETIC' if row['synthetic'] else 'AL-HUMAN',
             'locale':'es_ES','script':'latin','file_id':row['id'],'file_name':row['name'],
             'duration_seconds':row['bound_ms']/1000,'duration_is_lower_bound':True,
             'gold_text':row['transcript'],'decoy_text':text,'gold_token_count':len(row['words']),'decoy_token_count':len(decoy),
             'gold_segments':public_words(row['words']),'decoy_segments':public_words(decoy),
             'gold_whole_audio_tag':'synthetic_speech' if row['synthetic'] else 'none','decoy_whole_audio_tag':decoy_tag,
             'injection_count':len(row['injections']),'injections':row['injections'],
             'status':'ACTIVE' if row['injections'] else 'NOT_MODIFIED','not_modified_reason':reason,
             'source_document':row['source_document'],'source_answer_json_pointer':'/'+ '/'.join(str(x).replace('~','~0').replace('/','~1') for x in row['answer_path']),
             'source_selection':row['selection'],'source_issues':row['source_issues'],
             'source_answer_sha256':digest(canonical(row['answer'])),'source_answer_original':copy.deepcopy(row['answer']),
             'template_status':t['status'],'template_exclusion_reasons':reasons,
             'template_injection_ids':[x['injection_id'] for x in t['injections']],
             'error_groups_available':sorted(set(group(c) for c in available)),
             'selected_error_groups':sorted(set(group(c) for c in operations)),
             'operations':operations}
        full_key.append(key)
        catalog.append({'file_id':row['id'],'file_name':row['name'],'word_count':len(row['words']),
                        'injection_count':len(row['injections']),'families':sorted(set(x['family'] for x in row['injections'])),
                        'template_status':t['status'],'template_exclusion_reasons':reasons,'not_modified_reason':reason})
        if row['injections']:
            target=documents[row['source_document']]
            for part in row['answer_path']:target=target[part]
            target['segments']=[{'final_segmentId':i,'final_startTime':timestamp(w['s']),'final_endTime':timestamp(w['e']),'final_transcription':w['word']} for i,w in enumerate(decoy,1)]
            target['final_n_total_segments']=len(decoy)
            target['final_full_transcript']=text
            target['audio_synthetic']=decoy_tag=='synthetic_speech'
    write_json(out/'alignment_prefill_es_ES.json',{'fileMetadata':{'locale':'es_ES','workitemsCount':len(rows)},'items':prefill})
    template_doc={'format':'align-decoy-kit/v1','instructions':template_instructions,'decoys':corpus}
    write_json(out/'decoy_corpus.json',template_doc)
    write_json(out/'decoy_corpus_ACTIVE_ONLY.json',{**template_doc,'decoys':[r for r in corpus if r['status']=='ACTIVE']})
    write_json(out/'answer_key.json',full_key)
    write_json(out/'file_manifest.json',catalog)
    for name,doc in documents.items():write_json(out/'modified_deliveries'/name,doc)
    with zipfile.ZipFile(delivery) as z:
        for name in z.namelist():
            p=out/'original_deliveries'/name;p.parent.mkdir(exist_ok=True);p.write_bytes(z.read(name))
    write_csv_and_excel(out,full_key)
    boundary=collections.Counter(x['meta']['severity'] for r in full_key for x in r['injections'] if x['family'].startswith('BND-'))
    summary={'format_mode':mode,'seed':SEED,'source_workitems':len(rows),'per_record_json_files':len(prefill),
             'records_with_implanted_errors':sum(bool(r['injections']) for r in full_key),
             'records_not_modified':sum(not r['injections'] for r in full_key),
             'word_timing_records':sum(bool(r['words']) for r in rows),
             'total_injections':sum(len(r['injections']) for r in full_key),
             'injections_by_family':dict(collections.Counter(x['family'] for r in full_key for x in r['injections'])),
             'boundary_severities':dict(boundary),'template_active_records':sum(r['status']=='ACTIVE' for r in corpus),
             'template_inactive_records':sum(r['status']!='ACTIVE' for r in corpus),
             'template_supported_injections':sum(len(r['injections']) for r in corpus if r['status']=='ACTIVE'),
             'reference_selection':dict(collections.Counter(r['selection']['method'] for r in rows)),
             'limitations':['No matching audio supplied; no listening or platform import performed.',
                            'Gold means selected supplied answer, not independently verified truth.',
                            'duration_seconds is a conservative observed alignment bound, not measured clip duration.',
                            'WH gaps are verified between supplied word intervals, not verified acoustically silent.',
                            'Two existing source overlaps are preserved and excluded from active template records.'],
             'inputs':{delivery.name:digest(delivery.read_bytes()),template.name:digest(template.read_bytes()),reference.name:digest(reference.read_bytes())}}
    write_json(out/'summary.json',summary)
    copy_reference_tools(reference,out)
    (out/'README.md').write_text(readme(summary),encoding='utf-8')
    return summary


CSV_COLUMNS='decoy_id,batch,group,status,locale,file_id,file_name,voice_type,injection_id,family,score_group,band,weight,detect_rule,rule,target,plain_offset,left_anchor,right_anchor,gold_start,gold_end,decoy_start,decoy_end,shift_ms,fingerprint,cat1b_flag,cat2_fixes_applied,reinjected,text_changed,gold_text,decoy_text,severity,source_document,source_answer_json_pointer,template_status,template_supported,not_modified_reason,gold_whole_audio_tag,decoy_whole_audio_tag'.split(',')


def write_csv_and_excel(out,keys):
    rows=[]
    for record in keys:
        for x in record['injections'] or [{}]:
            m=x.get('meta',{});gold=m.get('gold',{});decoy=m.get('decoy',{})
            values={'decoy_id':record['decoy_id'],'batch':'es-deliveries-20261104','group':record['group'],'status':record['status'],
                    'locale':'es_ES','file_id':record['file_id'],'file_name':record['file_name'],'voice_type':'synthetic' if record['gold_whole_audio_tag']=='synthetic_speech' else 'source_not_marked_synthetic',
                    'injection_id':x.get('injection_id'),'family':x.get('family'),'score_group':score_group(x.get('family','')),
                    'band':x.get('band'),'weight':x.get('weight'),'detect_rule':m.get('detect',x.get('detect')),'rule':m.get('rule',x.get('rule')),
                    'target':m.get('word',m.get('from',m.get('joined'))),'plain_offset':m.get('plain_offset'),'left_anchor':m.get('left'),'right_anchor':m.get('right'),
                    'gold_start':gold.get('start'),'gold_end':gold.get('end'),'decoy_start':decoy.get('start'),'decoy_end':decoy.get('end'),
                    'shift_ms':m.get('shift_ms'),'fingerprint':x.get('fingerprint'),'cat1b_flag':bool(record['source_issues']),
                    'cat2_fixes_applied':False,'reinjected':False,'text_changed':record['gold_text']!=record['decoy_text'],
                    'gold_text':record['gold_text'],'decoy_text':record['decoy_text'],'severity':m.get('severity'),
                    'source_document':record['source_document'],'source_answer_json_pointer':record['source_answer_json_pointer'],
                    'template_status':record['template_status'],'template_supported':x.get('injection_id') in record['template_injection_ids'],
                    'not_modified_reason':record['not_modified_reason'],
                    'gold_whole_audio_tag':record['gold_whole_audio_tag'],'decoy_whole_audio_tag':record['decoy_whole_audio_tag']}
            rows.append(values)
    for name,selected in [('decoy_corpus_ALL.csv',rows),('decoy_corpus_CHANGED.csv',[r for r in rows if r['injection_id']])]:
        with (out/name).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=CSV_COLUMNS);writer.writeheader();writer.writerows(selected)
    import openpyxl
    wb=openpyxl.Workbook();ws=wb.active;ws.title='Injections'
    ws.append(CSV_COLUMNS)
    for r in rows:ws.append([r.get(k) for k in CSV_COLUMNS])
    ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
    files=wb.create_sheet('All records')
    headers=['file_id','file_name','injection_count','status','template_status','not_modified_reason','template_exclusion_reasons']
    files.append(headers)
    for r in keys:files.append([json.dumps(r[h],ensure_ascii=False) if isinstance(r[h],(list,dict)) else r[h] for h in headers])
    files.freeze_panes='A2';files.auto_filter.ref=files.dimensions
    wb.save(out/'answer_key.xlsx')


def score_group(family):
    if family.startswith('BND-'):return 'BOUNDARY'
    if family.startswith('SEG-'):return 'SEGMENTATION'
    if family.startswith('G-'):return 'GUIDELINE'
    return {'WD':'MISSING','WH':'HALLUCINATED','WS':'WRONG-WORD','CB-WHOLE':'CHECKBOX'}.get(family,family)


def copy_reference_tools(reference,out):
    with zipfile.ZipFile(reference) as z:
        for basename in ['alignmentDecoyScorer.js','run_selftest.js','Forced_Alignment_Guidelines_es_ES.pdf']:
            name=next(n for n in z.namelist() if n.endswith('/'+basename))
            p=out/'reference_tools'/basename;p.parent.mkdir(exist_ok=True);p.write_bytes(z.read(name))
    write_json(out/'decoy_change_manifest.json',{'fixed':[],'reinjected':[],'pulled':[],
               'note':'First build on these 297 records. Source issue/exclusion details are in file_manifest.json.'})


def readme(s):
    return f'''# Spanish alignment decoys — {s['source_workitems']} supplied records

## Files
- `alignment_prefill_es_ES.json`: combined trainee-facing machine prefill.
- `modified_transcripts/`: one trainee-facing JSON per original record ({s['per_record_json_files']} files).
- `modified_deliveries/`: original delivery schema with only the selected answer changed. Other annotator answers remain for traceability; do not show these history files to trainees as they contain unmodified reference answers. Original inputData is preserved.
- `decoy_corpus.json`: uploaded align-decoy-kit/v1 format, all records; only ACTIVE records are eligible for import.
- `decoy_corpus_ACTIVE_ONLY.json`: same template, active records only ({s['template_active_records']}).
- `answer_key.json`, `decoy_corpus_ALL.csv`, `decoy_corpus_CHANGED.csv`, `answer_key.xlsx`: answer keys, including original/modified words, offsets, changes in milliseconds, reasons, and source pointers. Keep these server-side.
- `original_deliveries/`: original JSON bytes, retained unchanged.
- `file_manifest.json`, `summary.json`, `validation_report.json`: complete accounting and limitations.
- `reference_tools/`: unchanged scorer, self-test and guideline PDF from the supplied reference ZIP. The old scorer is supplied as a reference; the platform template and this build's exact-diff validation are separate checks.

## Counts and interpretation
{s['records_with_implanted_errors']} records contain planted errors; {s['records_not_modified']} could not be modified in this mode. Every one of the {s['source_workitems']} input records is present and accounted for.
Mode: `{s['format_mode']}`. Boundary severity: minor 40–80 ms; major 100–300 ms; critical above 300 ms. Template imports retain only boundary shifts at least 150 ms and WD/WH/SEG-MERGE. Any other selected errors remain in the prefill and full answer key, not the template injections.

No new zero-length spans or overlaps are planted. The reference package's BND-ZERO and BND-OVERLAP cases are deliberately not copied: the agreed timing edits retain positive spans and introduce no new overlaps. Existing source overlaps are retained in the reference and never silently normalised. Multiple error types are spread over distinct word positions where possible. Short clips cannot contain every family or every boundary severity; available and selected groups are listed per record. Accent-dropping errors are not planted where the supplied reference has no accented tokens to remove.

Boundary shifts have signed integer millisecond deltas in each injection. A1/A2/A3 weights are explicitly 3/2/1 in this build; these are recorded per injection and are not a claim that group totals match the old 20-file package. The unchanged scorer supports the answer-key array: run `node reference_tools/run_selftest.js answer_key.json`. Do not give the template object to that old array-based runner. The full prefill and the template-supported subset intentionally define different tests: minor shifts and text-changing errors appear only in the full test. Keep the matching answer key with each.

`gold_segments` means the selected supplied reference: adjudication where available, otherwise the latest timestamped blind-pass answer. The other blind-pass is not arbitrarily merged with it. This is an assumed reference, not independent proof of correctness.

No matching audio was supplied. The 20 WAVs in the example ZIP are reference examples, not the audio for these records, and are not relabelled or included. Supply the matching audio before using an audio-import kit. `duration_seconds` is the maximum supplied input/final alignment end, a conservative lower bound rather than a measured duration. Timing edits stay inside that known bound; replace it with the actual measured duration before production import.

WH additions lie strictly within an annotated gap. Without audio, that gap cannot be certified as acoustically silent. Source synthetic flags are preserved in the reference. Full mode can deliberately hide that checkbox and records it as CB-WHOLE; these synthetic records remain INACTIVE in the template because that importer skips them.

## Reproduction
`python3 build.py --mode {s['format_mode']} --delivery PATH_TO_DELIVERY_ZIP --template PATH_TO_TEMPLATE_JSON --reference PATH_TO_REFERENCE_ZIP --out OUTPUT_DIRECTORY`
The builder uses the Python standard library plus openpyxl for the Excel answer key. Run `python3 validate.py OUTPUT_DIRECTORY` after building. No API key or audio API is used.
'''


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--mode',required=True,choices=['supported','full'])
    p.add_argument('--delivery',type=pathlib.Path,default=DEFAULT_DELIVERY)
    p.add_argument('--template',type=pathlib.Path,default=DEFAULT_TEMPLATE)
    p.add_argument('--reference',type=pathlib.Path,default=DEFAULT_REFERENCE)
    p.add_argument('--out',type=pathlib.Path,default=ROOT/'spanish_decoys_297')
    a=p.parse_args();print(json.dumps(build(a.mode,a.delivery,a.template,a.reference,a.out),indent=2))
