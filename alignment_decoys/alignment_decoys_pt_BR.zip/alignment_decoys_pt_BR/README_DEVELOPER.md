# Alignment Decoy Programme — Developer README

**v1 · first build · Portuguese (Brazil) (`pt_BR`) · 20 files · 83 injections · seed `20261027`**

This is the forced-alignment counterpart of the transcription decoy package. Same idea, same file set:
we know exactly what we changed in the machine pre-segmentation, so catching it is exact and evidenced.

---

## Files in this handover

| File | What to do with it |
|---|---|
| `alignment_prefill_pt_BR.json` | **Load this into the alignment tool as the machine pre-segmentation** of these 20 files. Sandbox format: `fileMetadata` + `items[]` (`id`, `name`, `transcript`, `source.words[]` with `word` / `start` / `end` in seconds). The planted errors are in here — word text and word start/end. Nothing in it marks a file as a decoy or as synthetic. |
| `audio/*.wav` | The 20 audio files (16 kHz mono). File names match `items[].name`. |
| `decoy_corpus.json` | **The answer key. Server-side only.** One record per file: gold vs decoy text and segments, whole-audio tag, every injection with family, band, weight, anchors and fingerprint. |
| `alignmentDecoyScorer.js` | The scoring engine. Zero dependencies. **Do not edit.** MD5 `81eecc591876963141fef0fabbd1ddc3` |
| `run_selftest.js` | `node run_selftest.js decoy_corpus.json` — re-runs the verification below. Output of this build: `selftest_report.txt`. |
| `decoy_corpus_ALL.csv` | Reference — all 20 files, 83 rows, one per injection |
| `decoy_corpus_CHANGED.csv` | Reference — files changed since the previous version. **Empty in v1** (header only) |
| `decoy_change_manifest.json` | The four ID lists: fixed, reinjected, pulled, flagged. **All empty in v1** |
| `decoy_summary.xlsx` | Bands & weights, score groups, every file, every injection, a 15-row spot-check sheet |
| `OPS_NOTES.md` | Full integration guide, output schemas, verdicts, bands, rotation policy |
| `Forced_Alignment_Guidelines_pt_BR.pdf` | The annotator guideline the decoys are built on |

---

## Do this

- [ ] **Load `alignment_prefill_pt_BR.json` as the pre-segmentation** for these 20 files, exactly as given.
      The timings are the test: if the tool re-runs its own aligner on these files, every boundary decoy disappears.
- [ ] **Load the corpus server-side and filter on `status`:**
  ```js
  const S = require('./alignmentDecoyScorer.js');
  const corpus = JSON.parse(fs.readFileSync('./decoy_corpus.json','utf8')).filter(c => c.status === 'ACTIVE');
  const decoys = S.indexCorpus(corpus);              // lookup by file_id (= items[].id) or decoy_id
  ```
- [ ] **On submit**, score it (see the submission shape below) and store the result:
  ```js
  if (decoys.isDecoy(fileId)) {
    const result = S.scoreDecoy(submission, decoys.get(fileId), { annotator_id, submitted_at, batch_id, seconds_spent });
    await db.alignment_decoy_results.insert(result);
  }
  ```
- [ ] **Serve the 20 files mixed into normal work**, in random order — never as a block.
- [ ] **Keep `decoy_corpus.json` off every front-end route** — it holds the gold alignment and says which files are synthetic.

## Do NOT do this

- Do not show the voice, the `group` (`AL-HUMAN` / `AL-SYNTH`) or anything from `decoy_corpus.json` in the tool
- Do not edit `alignmentDecoyScorer.js` — verified against this corpus (below)
- Do not let the tool snap or re-align the pre-filled timings of these files

---

## Submission shape

`scoreDecoy` accepts the submitted segments in any of these shapes:

```js
[{ word: 'zug', start: 1.23, end: 1.51 }, ...]                                 // segments only
{ segments: [...], whole_audio_tag: 'none' | 'synthetic_speech', discard_reason: null }
{ transcript: '...', source: { words: [...] }, whole_audio_tag: 'none' }      // an item in the pre-fill format
```

`whole_audio_tag` is the dustbin answer "Entirely synthetic speech" (guideline 2.5). Pass `'synthetic_speech'` when the
annotator marked the file as entirely synthetic, `'none'` otherwise. Leave it out and the synthetic check is
`INDETERMINATE` (never a miss). `discard_reason` is any other dustbin reason.

---

## Fields on each corpus record

| Field | Meaning |
|---|---|
| `decoy_id` | `ALN-PT-0001` … — pre-shuffled, not in serve order |
| `file_id`, `file_name` | Same as `items[].id` / `items[].name` in the pre-fill and the wav name |
| `gold_text`, `decoy_text` | Correct transcript vs what the pre-fill shows (space-separated segments) |
| `gold_segments`, `decoy_segments` | Correct alignment vs the pre-fill alignment (`word`, `start`, `end`) |
| `gold_whole_audio_tag` | `synthetic_speech` for the 3 entirely synthetic files, else `none`. The pre-fill never says it (`decoy_whole_audio_tag` = `none`) |
| `voice` | Voice name, gender and `type` (`human` / `synthetic`) — answer key only |
| `injections[]` | `family`, `band`, `weight`, `meta` (`detect`, `rule`, `word` / `from`→`to`, gold and decoy span, `shift_ms`, `left` / `right` anchors, `plain_offset`), `injection_id`, `fingerprint` |
| `status`, `cat1b_flag`, `cat2_fixes`, `reinjected` | As in the transcription corpus. v1: all `ACTIVE`, no flags, no fixes |

---

## Current state

| | |
|---|---|
| Files | **20** (17 human-sounding, 3 entirely synthetic) — every file carries decoys |
| Injections | **83** (80 alignment + 3 synthetic check) · A1 33 · A2 39 · A3 11 |
| Verification | 83/83 `MISSED` on decoy · 83/83 `CAUGHT` on gold · 80/80 `CAUGHT` on gold with ±20 ms jitter |
| Throughput | 0.149 ms per submission — call it inline, no queue |
