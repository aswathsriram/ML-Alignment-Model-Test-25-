# Alignment Decoy Programme — Developer README

**v1 · French (`fr_FR`) · part 1 of 10 · 100 of 1000 files · 395 injections · seed `20261112`**

This is the forced-alignment counterpart of the transcription decoy package. Same idea, same file set:
we know exactly what we changed in the machine pre-segmentation, so catching it is exact and evidenced.

---

## Files in this handover

| File | What to do with it |
|---|---|
| `alignment_prefill_fr_FR.json` | **Load this into the alignment tool as the machine pre-segmentation** of these 100 files. Sandbox format: `fileMetadata` + `items[]` (`id`, `name`, `transcript`, `source.words[]` with `word` / `start` / `end` in seconds). The planted errors are in here — word text and word start/end. Nothing in it marks a file as a decoy. |
| `audio/*.wav` | The 100 audio files (16 kHz mono). File names match `items[].name`. |
| `decoy_corpus.json` | **The answer key. Server-side only.** One record per file: gold vs decoy text and segments, voice, every injection with family, band, weight, anchors and fingerprint. |
| `alignmentDecoyScorer.js` | The scoring engine. Zero dependencies. **Do not edit.** MD5 `81eecc591876963141fef0fabbd1ddc3` |
| `run_selftest.js` | `node run_selftest.js decoy_corpus.json` — re-runs the verification below. Output of this build: `selftest_report.txt`. |
| `decoy_corpus_ALL.csv` | Reference — all 100 files, 395 rows, one per injection |
| `decoy_corpus_CHANGED.csv` | Reference — files changed since the previous version. **Empty in v1** (header only) |
| `decoy_change_manifest.json` | The four ID lists: fixed, reinjected, pulled, flagged. **All empty in v1** |
| `decoy_summary.xlsx` | Bands & weights, score groups, every file, every injection, a 15-row spot-check sheet |
| `OPS_NOTES.md` | Full integration guide, output schemas, verdicts, bands, rotation policy |
| `Forced_Alignment_Guidelines_fr_FR.pdf` | The annotator guideline the decoys are built on |

---

## Do this

- [ ] **Load `alignment_prefill_fr_FR.json` as the pre-segmentation** for these 100 files, exactly as given.
      The timings are the test: if the tool re-runs its own aligner on these files, every boundary decoy disappears.
- [ ] **Load the corpus server-side and filter on `status`:**
  ```js
  const S = require('./alignmentDecoyScorer.js');
  const corpus = JSON.parse(fs.readFileSync('./decoy_corpus.json','utf8')).filter(c => c.status === 'ACTIVE');
  const decoys = S.indexCorpus(corpus);              // lookup by file_id (= items[].id) or decoy_id
  ```
- [ ] **On submit**, score it (see the submission shape below) and store the result:
  ```js
  if (decoys.isDecoy(fileId)) {
    const result = S.scoreDecoy(submission, decoys.get(fileId), { annotator_id, submitted_at, batch_id, seconds_spent });
    await db.alignment_decoy_results.insert(result);
  }
  ```
- [ ] **Serve the 100 files mixed into normal work**, in random order — never as a block.
- [ ] **Keep `decoy_corpus.json` off every front-end route** — it holds the gold alignment.

## Do NOT do this

- Do not show the voice, the `group` or anything from `decoy_corpus.json` in the tool
- Do not edit `alignmentDecoyScorer.js` — verified against this corpus (below)
- Do not let the tool snap or re-align the pre-filled timings of these files

---

## Submission shape

`scoreDecoy` accepts the submitted segments in any of these shapes:

```js
[{ word: 'zug', start: 1.23, end: 1.51 }, ...]                                 // segments only
{ segments: [...], whole_audio_tag: 'none' | 'synthetic_speech', discard_reason: null }
{ transcript: '...', source: { words: [...] }, whole_audio_tag: 'none' }      // an item in the pre-fill format
```

`whole_audio_tag` is the dustbin answer "Entirely synthetic speech" (guideline 2.5). Every file in this set is natural,
human-sounding speech, so the right answer is always `'none'`: a file marked synthetic or discarded scores every
injection `MISSED` (`false_synthetic: true`). `discard_reason` is any other dustbin reason.

---

## Fields on each corpus record

| Field | Meaning |
|---|---|
| `decoy_id` | `ALN-FR-0001` … — pre-shuffled, not in serve order |
| `file_id`, `file_name` | Same as `items[].id` / `items[].name` in the pre-fill and the wav name |
| `gold_text`, `decoy_text` | Correct transcript vs what the pre-fill shows (space-separated segments) |
| `gold_segments`, `decoy_segments` | Correct alignment vs the pre-fill alignment (`word`, `start`, `end`) |
| `gold_whole_audio_tag` | `none` for every file: there are no synthetic files in this set |
| `voice` | Voice name, gender, ElevenLabs voice id and `type` (`human`) — answer key only |
| `injections[]` | `family`, `band`, `weight`, `meta` (`detect`, `rule`, `word` / `from`→`to`, gold and decoy span, `shift_ms`, `left` / `right` anchors, `plain_offset`), `injection_id`, `fingerprint` |
| `status`, `cat1b_flag`, `cat2_fixes`, `reinjected` | As in the transcription corpus. v1: all `ACTIVE`, no flags, no fixes |

---

## Current state

| | |
|---|---|
| Files | **100** of 1000 (part 1 of 10) — all human-sounding, none synthetic; every file carries decoys |
| Injections | **395** · A1 147 · A2 127 · A3 121 |
| Verification | 395/395 `MISSED` on decoy · 395/395 `CAUGHT` on gold · 395/395 `CAUGHT` on gold with ±20 ms jitter |
| Throughput | 0.055 ms per submission — call it inline, no queue |
