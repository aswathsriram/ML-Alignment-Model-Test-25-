# Alignment Decoy Programme — Integration & Ops

**Corpus:** part 9 of 10 · 100 of 1000 files · 413 injections · French (`fr_FR`) · seed `20261112`
**Source:** 1000 new transcripts written to the `fr_FR` forced-alignment guideline, voiced with ElevenLabs by 50
native French voices (25 female, 25 male; young, middle-aged and older), all natural human-sounding speech with
breathing, sighs and uneven pauses — none synthetic. Every clip was checked by speech-to-text against its transcript
and made again until it matched; gold alignment by forced alignment plus loudness-based correction at pauses.

---

## 1. Files

| File | What it is |
|---|---|
| `alignment_prefill_fr_FR.json` | What the annotator is served: the pre-segmentation with the planted errors. |
| `audio/` | The 100 wav files. |
| `decoy_corpus.json` | The corpus and answer key. **Never expose it to the annotation front end.** |
| `decoy_corpus_ALL.csv` | Same data, one row per injection, for spreadsheets and SQL. |
| `alignmentDecoyScorer.js` | The scoring engine. Zero dependencies. |
| `decoy_summary.xlsx` | Bands & weights, score groups, files, injections, spot-check sample. |

---

## 2. Wiring it up

```js
const fs = require('fs');
const S  = require('./alignmentDecoyScorer.js');
const corpus = JSON.parse(fs.readFileSync('./decoy_corpus.json', 'utf8')).filter(c => c.status === 'ACTIVE');
const decoys = S.indexCorpus(corpus);
```

### When a task is served

```js
if (decoys.isDecoy(fileId)) {
  servePreSegmentation(prefill.items.find(i => i.id === fileId));   // the planted pre-segmentation, as is
} else {
  servePreSegmentation(normalAligner(fileId));
}
```

### When a submission arrives

```js
if (decoys.isDecoy(fileId)) {
  const entry  = decoys.get(fileId);
  const result = S.scoreDecoy({ segments, whole_audio_tag, discard_reason }, entry, {
    annotator_id: userId, submitted_at: new Date().toISOString(), batch_id: batchId, seconds_spent: secondsSpent,
  });
  await db.alignment_decoy_results.insert(result);
  await db.alignment_decoy_residuals.insert(S.classifyResiduals({ segments }, entry));   // advisory only
}
```

### The daily pull

```js
const report = S.buildDailyReport(rows, { from, to });        // all-time within range
const recent = S.buildDailyReport(rows, { window: 20 });      // last 20 decoys per person
fs.writeFileSync('daily.csv', S.reportToCsv(report));
const detail = S.injectionsToRows(rows);                      // per-injection audit table
```

---

## 3. Output shapes

### `scoreDecoy` — per submission

```json
{
  "decoy_id": "ALN-FR-0020", "group": "AL-HUMAN", "file_id": "cm3m82qbl62eqgzmxlxkmndms",
  "annotator_id": "annotator7230", "injection_count": 5, "caught": 4, "missed": 1, "indeterminate": 0,
  "excluded": 0, "file_is_synthetic": false, "marked_synthetic": false, "false_synthetic": false,
  "points_possible": 1.372, "points_lost": 0.314, "score_percent": 77.1,
  "missed_families": ["BND-ZERO"], "missed_bands": ["A1"],
  "by_band": { "A1": { ... }, "A2": { ... }, "A3": { ... } },
  "by_family": { ... }, "by_group": { "BOUNDARY": { ... }, "WRONG-WORD": { ... } },
  "injections": [ /* per-injection detail, below */ ]
}
```

### Per-injection detail (a boundary decoy)

```json
{
  "injection_id": "ALN-FR-0020-3", "family": "BND-ZERO", "group": "BOUNDARY", "band": "A1", "weight": 0.314,
  "detect_rule": "ZERO_LENGTH", "verdict": "MISSED", "confidence": 1,
  "evidence": { "word": "une", "edge": "end", "gold_s": 4.16,
    "planted_s": 4.0, "submitted_s": 4.0,
    "remaining_error_ms": -160, "planted_shift_ms": -160 }
}
```

---

## 4. Verdicts

| Verdict | Meaning |
|---|---|
| `CAUGHT` | The annotator found and fixed the planted error |
| `MISSED` | The planted error survived into the submission |
| `INDETERMINATE` | Can't be judged (region rewritten, a third value, a partial fix). **Route to human review — never count as a miss.** |

**Timing rule.** An edge is `CAUGHT` when it is back within **30 ms** of gold. It is `MISSED` when at least half of the
planted shift is still there, in the planted direction. Anything in between is `INDETERMINATE`.

**Synthetic answer.** No file in this set is synthetic. A file marked synthetic or discarded → every injection
`MISSED` and `false_synthetic: true` (the daily report counts these).

---

## 5. Bands, score groups and weights

Bands follow the transcription corpus: **A1** obvious (missing it costs the most), **A2** medium, **A3** subtle.
Boundary bands: minor 40–80 ms = **A3**; major 100–300 ms = **A2**; more than 300 ms, or running into the next word = **A1**.
Zero length = **A1**.

Each score group gets a fixed share of **100 alignment points per part**, spread over its injections in the ratio
A1 3 : A2 2 : A3 1 (so an A1 miss costs three times an A3 miss). Planted counts follow the same mix. There are no
split, join, capital-letter, punctuation or digit errors in this set.

| Score group | Share | Injections |
|---|---|---|
| BOUNDARY | 50% | 213 |
| MISSING | 12.5% | 56 |
| HALLUCINATED | 12.5% | 45 |
| WRONG-WORD | 12.5% | 52 |
| GUIDELINE | 12.5% | 47 |

| Family | What is planted | Group | `detect` | Band rule | Count |
|---|---|---|---|---|---|
| `BND-MINOR` | Boundary mismatch, minor (40-80 ms) | BOUNDARY | `EDGE_AT_SLOT` | A3: edge moved 40-80 ms | 51 |
| `BND-MAJOR` | Boundary mismatch, major (100-300 ms A2, >300 ms A1) | BOUNDARY | `EDGE_AT_SLOT` | A2: edge moved 100-300 ms · A1: more than 300 ms | 111 |
| `BND-OVERLAP` | Segment runs into the neighbouring word (same-speaker overlap) | BOUNDARY | `EDGE_AT_SLOT` | A1: edge runs into the next / previous word (same-speaker overlap) | 24 |
| `BND-ZERO` | Zero-length segment | BOUNDARY | `ZERO_LENGTH` | A1: start = end | 27 |
| `WD` | Missing segment: spoken word has no segment | MISSING | `WORD_AT_SLOT_PRESENT` | A1: content word · A2: function word / short word | 56 |
| `WH` | Hallucinated segment over silence / breath | HALLUCINATED | `SEGMENT_AT_SLOT_ABSENT` | A1: segment over silence · A2: segment over a breath / sigh | 45 |
| `WS` | Wrong word / homophone | WRONG-WORD | `WORD_AT_SLOT_SUBSTITUTED` | A1: different word or complete word written cut off · A2: homophone / spoken form · A3: small form or spelling change | 52 |
| `G-ACCENT` | Accent / umlaut / cedilla dropped | GUIDELINE | `WORD_AT_SLOT_SUBSTITUTED` | A3: accent / cedilla dropped | 38 |
| `G-BACKCH` | Filler / backchannel spelling | GUIDELINE | `WORD_AT_SLOT_SUBSTITUTED` | A3: filler / backchannel misspelt | 9 |

---

## 6. Category A vs B

**Category A** is what this corpus measures: we know exactly what we changed. **Category B** (`classifyResiduals`) is a
diff against gold outside the injected regions — a coaching signal only (`advisory: true`). Gold timings are accurate
to about ±20–30 ms, so B ignores edge differences under 100 ms.

---

## 7. Anti-detection

- **Never expose `decoy_corpus.json` to the front end.** It is the answer key.
- **Serve decoys through the normal queue.** File names and ids are random (`<uuid>_NNN.wav`, `cm…`), the pre-fill lists
  files in an order unrelated to `decoy_id`, and nothing in the pre-fill marks a decoy.
- **The injections look like ordinary machine pre-segmentation errors**: edges a little off, a segment over a breath, a
  missing word, a homophone, a dropped accent. Exactly the errors the guideline (2.3) tells annotators to fix.
- **Rotate.** Retire a decoy after roughly 30 exposures; regenerate with a new seed.

---

## 8. Known limits

- **Gold timing precision is about ±20–30 ms** (forced alignment plus loudness-based correction at pauses). That is why
  minor decoys start at 40 ms and the catch tolerance is 30 ms. The self-test shows gold with ±20 ms random jitter on
  every edge still scores `CAUGHT` 413/413.
- **The pre-segmentation must be served as given.** If the alignment tool re-aligns on load, boundary decoys
  (50 % of the points) vanish; transcript-level decoys (text, missing, hallucinated) still work.
- **Band assignment is a design choice, not a measurement.** Tune it against real miss rates after the first two weeks.
- **All audio is generated speech** (ElevenLabs), made to sound human: natural voices with breathing, sighs and
  uneven pauses. No file is robotic or marked synthetic.

---

## 9. Reproducing the corpus

From the repository root:

```bash
python french_1000/build_transcripts.py    # spec/batch_*.txt -> transcripts.jsonl (1000 clips, voices)
python french_1000/generate.py            # audio + gold alignment (ElevenLabs; skips clips already made)
python french_1000/build_package.py       # plan + inject + package + self-test + 10 zips
```

Seed `20261112` regenerates this corpus byte-identically from the same audio. Change the seed for a fresh set.
